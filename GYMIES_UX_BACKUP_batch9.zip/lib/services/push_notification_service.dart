import 'dart:async';
import 'dart:io';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';

import 'package:gymies_app/services/auth_service.dart';
import 'package:gymies_app/services/gymies_api.dart';

/// Remote push via FCM (Android) / APNs (iOS via FCM).
/// Voor meldingen wanneer de app gesloten is.
class PushNotificationService {
  PushNotificationService({
    required AuthService auth,
    required GymiesApi api,
  })  : _auth = auth,
        _api = api {
    _auth.addListener(_onAuthChanged);
  }

  final AuthService _auth;
  final GymiesApi _api;
  bool _initialized = false;
  String? _lastRegisteredToken;

  bool get isInitialized => _initialized;

  /// Initialiseer FCM. Firebase.initializeApp() is al aangeroepen in main().
  Future<void> start() async {
    if (_initialized) return;
    _initialized = true;
    if (kDebugMode) debugPrint('[PushNotification] FCM start');

    // iOS: vraag toestemming
    if (Platform.isIOS) {
      final settings = await FirebaseMessaging.instance.requestPermission(
        alert: true,
        badge: true,
        sound: true,
      );
      if (kDebugMode) {
        debugPrint('[PushNotification] iOS permission: ${settings.authorizationStatus}');
      }
    }

    // Luister naar token refresh
    FirebaseMessaging.instance.onTokenRefresh.listen(_registerToken);

    // Luister naar berichten (background/terminated: via top-level handler)
    FirebaseMessaging.onMessage.listen(_onForegroundMessage);
    FirebaseMessaging.onMessageOpenedApp.listen(_onNotificationTap);

    // Check of app geopend werd via notification (cold start)
    final initialMessage = await FirebaseMessaging.instance.getInitialMessage();
    if (initialMessage != null) {
      _handleNotificationPayload(initialMessage);
    }

    // Eerste token ophalen
    await _registerCurrentToken();
  }

  void _onAuthChanged() {
    if (!_auth.isLoggedIn) {
      _lastRegisteredToken = null;
    } else if (_initialized) {
      _registerCurrentToken();
    }
  }

  Future<void> _registerCurrentToken() async {
    if (!_auth.isLoggedIn) return;
    try {
      final token = await FirebaseMessaging.instance.getToken();
      if (token != null && token.isNotEmpty) {
        await _registerToken(token);
      }
    } catch (e) {
      if (kDebugMode) debugPrint('[PushNotification] getToken failed: $e');
    }
  }

  Future<void> _registerToken(String token) async {
    if (!_auth.isLoggedIn || token == _lastRegisteredToken) return;
    try {
      final platform = Platform.isIOS ? 'ios' : 'android';
      await _api.registerDeviceToken(token: token, platform: platform);
      _lastRegisteredToken = token;
      if (kDebugMode) debugPrint('[PushNotification] Token registered ($platform)');
    } catch (e) {
      if (kDebugMode) debugPrint('[PushNotification] register failed: $e');
    }
  }

  void _onForegroundMessage(RemoteMessage message) {
    if (kDebugMode) {
      debugPrint('[PushNotification] Foreground: ${message.notification?.title}');
    }
    // Foreground: WebSocket + LocalPush tonen al meldingen.
    // Optioneel: ook hier lokale notificatie tonen.
  }

  void _onNotificationTap(RemoteMessage message) {
    _handleNotificationPayload(message);
  }

  void _handleNotificationPayload(RemoteMessage message) {
    final data = message.data;
    if (data.isEmpty) return;
    // Deep link of navigatie op basis van type
    // Bijv. data['type'] == 'booking' -> open sessies
    // Wordt afgehandeld door DeepLinkService of navigator
    if (kDebugMode) {
      debugPrint('[PushNotification] Tap payload: $data');
    }
  }

  /// Logout: token van server verwijderen (backend ondersteunt dit).
  Future<void> unregister() async {
    _lastRegisteredToken = null;
    try {
      await FirebaseMessaging.instance.deleteToken();
    } catch (_) {}
  }

  void dispose() {
    _auth.removeListener(_onAuthChanged);
  }
}
