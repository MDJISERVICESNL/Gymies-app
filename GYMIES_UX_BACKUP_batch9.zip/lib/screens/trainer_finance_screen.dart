import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

import '../services/api_client.dart';
import '../services/gymies_api.dart';
import '../theme/gymies_theme.dart';
import '../utils/haptics.dart';
import '../utils/map_utils.dart';
import 'widgets/gymies_app_bar.dart';
import 'widgets/gymies_dialog.dart';
import 'widgets/trainer_state_views.dart';

class TrainerFinanceScreen extends StatefulWidget {
  const TrainerFinanceScreen({super.key});

  @override
  State<TrainerFinanceScreen> createState() => _TrainerFinanceScreenState();
}

class _TrainerFinanceScreenState extends State<TrainerFinanceScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _loading = true;
  String? _error;
  Map<String, dynamic> _forecast = {};
  Map<String, dynamic> _previousMonth = {};
  Map<String, dynamic> _payoutSettings = {};
  Map<String, dynamic> _payoutPreview = {};
  List<Map<String, dynamic>> _payouts = [];
  List<Map<String, dynamic>> _payoutCalendar = [];
  List<Map<String, dynamic>> _invoices = [];
  bool _savingSettings = false;
  Map<String, dynamic> _revenueByType = {};

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _load();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final api = context.read<GymiesApi>();
      // Laad alles individueel — als een route nog niet bestaat op de
      // backend, vangen we die per call op zodat de rest wél laadt.
      Map<String, dynamic> forecast = {};
      Map<String, dynamic> previousMonth = {};
      Map<String, dynamic> settings = {};
      Map<String, dynamic> preview = {};
      List<Map<String, dynamic>> payouts = [];
      List<Map<String, dynamic>> calendar = [];
      List<Map<String, dynamic>> invoices = [];

      try {
        forecast = await api.getTrainerRevenueForecast();
      } catch (e) {
        debugPrint('[Finance] forecast fout: $e');
      }
      try { previousMonth = await api.getTrainerRevenueForecast(); } catch (_) {}
      try { settings = await api.getTrainerPayoutSettings(); } catch (e) {
        debugPrint('[Finance] payout-settings fout: $e');
      }
      try { preview = await api.getTrainerPayoutPreview(); } catch (e) {
        debugPrint('[Finance] payout-preview fout: $e');
      }
      try { payouts = await api.getTrainerPayouts(); } catch (e) {
        debugPrint('[Finance] payouts fout: $e');
      }
      try { calendar = await api.getTrainerPayoutCalendar(); } catch (e) {
        debugPrint('[Finance] payout-calendar fout: $e');
      }
      try { invoices = await api.getTrainerInvoices(); } catch (e) {
        debugPrint('[Finance] invoices fout: $e');
      }
      if (!mounted) return;
      // Parse revenue_by_type from forecast
      final revenueByType = forecast['revenue_by_type'] ?? {};
      setState(() {
        _forecast = forecast;
        _previousMonth = previousMonth;
        _payoutSettings = settings;
        _payoutPreview = preview;
        _payouts = payouts;
        _payoutCalendar = calendar;
        _invoices = invoices;
        _revenueByType = revenueByType;
        _loading = false;
      });
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.message;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _error = 'Kon geavanceerde financiën niet laden.';
        _loading = false;
      });
    }
  }

  Future<void> _requestPayoutNow() async {
    Haptics.light();
    try {
      await context.read<GymiesApi>().requestTrainerPayoutNow();
      if (!mounted) return;
      Haptics.success();
      _showSuccess('Uitbetalingsverzoek verstuurd');
      await _load();
    } on ApiException catch (e) {
      if (!mounted) return;
      Haptics.error();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.message), backgroundColor: Colors.red),
      );
    }
  }

  Future<void> _editPayoutSettings() async {
    Haptics.selection();
    final methodController = TextEditingController(
      text: mapStr(_payoutSettings, ['method', 'payout_method']).isNotEmpty
          ? mapStr(_payoutSettings, ['method', 'payout_method'])
          : 'bank_transfer',
    );
    final ibanController = TextEditingController(
      text: mapStr(_payoutSettings, ['iban', 'iban_number']),
    );
    final nameController = TextEditingController(
      text: mapStr(_payoutSettings, [
        'account_name',
        'accountName',
        'beneficiary_name',
      ]),
    );
    await GymiesDialog.form<void>(
      context,
      title: 'Payout instellingen',
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: methodController,
            decoration: const InputDecoration(labelText: 'Methode'),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: ibanController,
            decoration: const InputDecoration(labelText: 'IBAN'),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: nameController,
            decoration: const InputDecoration(labelText: 'Rekeningnaam'),
          ),
        ],
      ),
      onConfirm: _savingSettings
          ? null
          : () async {
              Haptics.light();
              Navigator.of(context).pop();
              setState(() => _savingSettings = true);
              try {
                await context
                    .read<GymiesApi>()
                    .updateTrainerPayoutSettings(
                      method: methodController.text.trim(),
                      iban: ibanController.text.trim(),
                      accountName: nameController.text.trim(),
                    );
                if (!mounted) return;
                Haptics.success();
                _showSuccess('Payout instellingen opgeslagen');
                await _load();
              } on ApiException catch (e) {
                if (!mounted) return;
                Haptics.error();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(e.message),
                    backgroundColor: Colors.red,
                  ),
                );
              } finally {
                if (mounted) setState(() => _savingSettings = false);
              }
            },
    );
  }

  Future<void> _loadQuarterZipInfo() async {
    Haptics.light();
    try {
      final data = await context
          .read<GymiesApi>()
          .getTrainerInvoicesQuarterZip();
      if (!mounted) return;
      final url = data['url']?.toString();
      Haptics.success();
      _showSuccess(
        url == null || url.isEmpty ? 'ZIP export gestart' : 'ZIP ready',
      );
    } on ApiException catch (e) {
      if (!mounted) return;
      Haptics.error();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.message), backgroundColor: Colors.red),
      );
    }
  }

  void _showSuccess(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: GymiesColors.darkBlue),
    );
  }

  int? _toInt(dynamic v) {
    if (v is int) return v;
    if (v is num) return v.toInt();
    return int.tryParse(v?.toString() ?? '');
  }

  String _currency(dynamic cents) {
    final v = _toInt(cents);
    if (v == null) return '-';
    return '€${(v / 100).toStringAsFixed(2)}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F8FA),
      appBar: GymiesAppBar(
        title: 'Financiën+',
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(48),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
            child: TabBar(
              controller: _tabController,
              isScrollable: true,
              tabAlignment: TabAlignment.start,
              indicator: BoxDecoration(
                color: GymiesColors.primary,
                borderRadius: BorderRadius.circular(20),
              ),
              indicatorSize: TabBarIndicatorSize.tab,
              dividerColor: Colors.transparent,
              labelColor: GymiesColors.darkBlue,
              unselectedLabelColor: Colors.white.withValues(alpha: 0.6),
              labelStyle: GoogleFonts.sora(fontSize: 13, fontWeight: FontWeight.w600),
              unselectedLabelStyle: GoogleFonts.sora(fontSize: 13, fontWeight: FontWeight.w500),
              tabs: const [
                Tab(text: 'Prognose'),
                Tab(text: 'Uitbetalingen'),
                Tab(text: 'Instellingen'),
                Tab(text: 'Facturen'),
              ],
            ),
          ),
        ),
      ),
      body: GymiesListBody(
        loading: _loading,
        error: _error,
        onRefresh: _load,
        child: TabBarView(
          controller: _tabController,
          children: [
            _forecastTab(),
            _payoutsTab(),
            _settingsTab(),
            _invoicesTab(),
          ],
        ),
      ),
    );
  }

  Widget _forecastKpi(String label, String value, IconData icon, Color color, {int? deltaCents}) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 22,
                height: 22,
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Icon(icon, size: 12, color: color),
              ),
              const SizedBox(width: 6),
              Flexible(
                child: Text(
                  label,
                  style: GoogleFonts.sora(fontSize: 10, color: Colors.grey.shade600),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            value,
            style: GoogleFonts.sora(fontSize: 18, fontWeight: FontWeight.w800, color: GymiesColors.darkBlue),
          ),
          if (deltaCents != null) ...[
            const SizedBox(height: 4),
            _buildDeltaChip(deltaCents),
          ],
        ],
      ),
    );
  }

  Widget _buildDeltaChip(int deltaCents) {
    final isPositive = deltaCents >= 0;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: isPositive ? Colors.green.shade50 : Colors.red.shade50,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            isPositive ? Icons.trending_up : Icons.trending_down,
            size: 12,
            color: isPositive ? Colors.green.shade700 : Colors.red.shade700,
          ),
          const SizedBox(width: 2),
          Text(
            '${isPositive ? '+' : ''}€${(deltaCents.abs() / 100).toStringAsFixed(0)}',
            style: GoogleFonts.sora(
              fontSize: 10,
              fontWeight: FontWeight.w600,
              color: isPositive ? Colors.green.shade700 : Colors.red.shade700,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRevenueBreakdown() {
    if (_revenueByType.isEmpty) {
      return const SizedBox.shrink();
    }

    final sessiesData = _revenueByType['sessies'] ?? {};
    final pakkettenData = _revenueByType['pakketten'] ?? {};
    final groepslessenData = _revenueByType['groepslessen'] ?? {};

    final sessiesCents = _toInt(sessiesData['cents'] ?? sessiesData['amount'] ?? 0) ?? 0;
    final pakkettenCents = _toInt(pakkettenData['cents'] ?? pakkettenData['amount'] ?? 0) ?? 0;
    final groepslessenCents = _toInt(groepslessenData['cents'] ?? groepslessenData['amount'] ?? 0) ?? 0;

    final totalCents = sessiesCents + pakkettenCents + groepslessenCents;
    if (totalCents == 0) {
      return const SizedBox.shrink();
    }

    final sessiesPercent = ((sessiesCents / totalCents) * 100).toStringAsFixed(0);
    final pakkettenPercent = ((pakkettenCents / totalCents) * 100).toStringAsFixed(0);
    final groepslessenPercent = ((groepslessenCents / totalCents) * 100).toStringAsFixed(0);

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 26,
                  height: 26,
                  decoration: BoxDecoration(
                    color: Colors.green.shade700.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(7),
                  ),
                  child: Icon(Icons.pie_chart_rounded, size: 14, color: Colors.green.shade700),
                ),
                const SizedBox(width: 10),
                Text(
                  'Omzet verdeling',
                  style: GoogleFonts.sora(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: GymiesColors.darkBlue,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            // Sessies bar
            _buildRevenueTypeBar(
              label: 'Sessies',
              percent: double.parse(sessiesPercent),
              amount: sessiesCents,
              color: Colors.blue.shade500,
            ),
            const SizedBox(height: 12),
            // Pakketten bar
            _buildRevenueTypeBar(
              label: 'Pakketten',
              percent: double.parse(pakkettenPercent),
              amount: pakkettenCents,
              color: Colors.green.shade500,
            ),
            const SizedBox(height: 12),
            // Groepslessen bar
            _buildRevenueTypeBar(
              label: 'Groepslessen',
              percent: double.parse(groepslessenPercent),
              amount: groepslessenCents,
              color: Colors.orange.shade500,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRevenueTypeBar({
    required String label,
    required double percent,
    required int amount,
    required Color color,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              label,
              style: GoogleFonts.sora(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: GymiesColors.darkBlue,
              ),
            ),
            Row(
              children: [
                Text(
                  '${percent.toStringAsFixed(0)}%',
                  style: GoogleFonts.sora(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: color,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  _currency(amount),
                  style: GoogleFonts.sora(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: GymiesColors.darkBlue,
                  ),
                ),
              ],
            ),
          ],
        ),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: percent / 100,
            backgroundColor: Colors.grey.shade200,
            valueColor: AlwaysStoppedAnimation(color),
            minHeight: 6,
          ),
        ),
      ],
    );
  }

  List<_ForecastBarPoint> _forecastChartPoints() {
    final monthCents = _toInt(mapPick(_forecast, [
      'month_estimate_cents',
      'monthEstimateCents',
      'expected_month_cents',
    ])) ?? 0;
    final forecastCents = _toInt(mapPick(_forecast, [
      'forecast_cents',
      'forecastCents',
      'total_forecast_cents',
    ])) ?? 0;
    final weekly = mapPick(_forecast, [
      'weekly_breakdown',
      'by_week',
      'weeks',
    ]);
    if (weekly is List && weekly.isNotEmpty) {
      return weekly.asMap().entries.map((e) {
        final v = e.value;
        final map = v is Map ? Map<String, dynamic>.from(v) : <String, dynamic>{};
        final cents = _toInt(mapPick(map, ['cents', 'amount_cents', 'value'])) ?? 0;
        final label = mapStr(map, ['label', 'week', 'period']) != ''
            ? mapStr(map, ['label', 'week', 'period'])
            : 'W${e.key + 1}';
        return _ForecastBarPoint(label: label, value: cents / 100.0);
      }).toList();
    }
    final points = <_ForecastBarPoint>[];
    if (monthCents > 0) {
      points.add(_ForecastBarPoint(label: 'Deze maand', value: monthCents / 100.0));
    }
    if (forecastCents > 0 && forecastCents != monthCents) {
      points.add(_ForecastBarPoint(label: 'Forecast', value: forecastCents / 100.0));
    }
    if (points.isEmpty && (monthCents > 0 || forecastCents > 0)) {
      points.add(_ForecastBarPoint(
        label: 'Verwacht',
        value: (monthCents > 0 ? monthCents : forecastCents) / 100.0,
      ));
    }
    return points;
  }

  Widget _forecastTab() {
    final chartPoints = _forecastChartPoints();
    final monthEstimateCents = _toInt(mapPick(_forecast, [
      'month_estimate_cents',
      'monthEstimateCents',
      'expected_month_cents',
    ])) ?? 0;
    final forecastCents = _toInt(mapPick(_forecast, [
      'forecast_cents',
      'forecastCents',
      'total_forecast_cents',
    ])) ?? 0;
    final previousMonthCents = _toInt(mapPick(_previousMonth, [
      'month_estimate_cents',
      'monthEstimateCents',
      'previous_month_cents',
      'lastMonthCents',
    ])) ?? 0;
    final deltaCents = monthEstimateCents - previousMonthCents;
    final weeklyAverage = monthEstimateCents > 0 ? (monthEstimateCents / 4).toInt() : 0;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Section 1: Revenue Overview Cards
        if (monthEstimateCents > 0 || forecastCents > 0) ...[
          Row(
            children: [
              Expanded(child: _forecastKpi('Deze maand', _currency(monthEstimateCents), Icons.account_balance_wallet_rounded, GymiesColors.darkBlue, deltaCents: previousMonthCents > 0 ? deltaCents : null)),
              const SizedBox(width: 10),
              Expanded(child: _forecastKpi('Forecast', _currency(forecastCents), Icons.trending_up_rounded, GymiesColors.primary)),
              const SizedBox(width: 10),
              Expanded(child: _forecastKpi('Gem./week', _currency(weeklyAverage), Icons.bar_chart_rounded, GymiesColors.darkBlue)),
            ],
          ),
          const SizedBox(height: 16),
        ],
        // Section 1.5: Revenue Breakdown (Omzet verdeling)
        if (_revenueByType.isNotEmpty) ...[
          _buildRevenueBreakdown(),
          const SizedBox(height: 16),
        ],
        // Section 2: Bar Chart Card
        if (chartPoints.isNotEmpty) ...[
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.04),
                  blurRadius: 10,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 26,
                        height: 26,
                        decoration: BoxDecoration(
                          color: GymiesColors.darkBlue.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(7),
                        ),
                        child: const Icon(Icons.bar_chart_rounded, size: 14, color: GymiesColors.darkBlue),
                      ),
                      const SizedBox(width: 10),
                      Text(
                        'Omzetverwachting',
                        style: GoogleFonts.sora(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: GymiesColors.darkBlue,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  _ForecastBarChart(points: chartPoints),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
        ] else ...[
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.04),
                  blurRadius: 10,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  Icon(
                    Icons.bar_chart_rounded,
                    size: 40,
                    color: Colors.grey.shade400,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Nog geen forecast data',
                    style: GoogleFonts.sora(
                      fontSize: 14,
                      color: Colors.grey.shade600,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Na je eerste boekingen verschijnt hier een omzetverwachting.',
                    textAlign: TextAlign.center,
                    style: GoogleFonts.sora(
                      fontSize: 12,
                      color: Colors.grey.shade500,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
        ],
      ],
    );
  }

  Widget _payoutsTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.04),
                blurRadius: 10,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: ListTile(
            leading: Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: GymiesColors.primary.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.account_balance_rounded, size: 18, color: GymiesColors.darkBlue),
            ),
            title: Text(
              'Payout preview',
              style: GoogleFonts.sora(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: GymiesColors.darkBlue,
              ),
            ),
            subtitle: Text(
              'Beschikbaar: ${_currency(mapPick(_payoutPreview, ['available_cents', 'availableCents', 'amount_cents']))}',
              style: GoogleFonts.sora(fontSize: 13),
            ),
          ),
        ),
        const SizedBox(height: 12),
        FilledButton.icon(
          onPressed: _requestPayoutNow,
          style: FilledButton.styleFrom(
            backgroundColor: GymiesColors.primary,
            foregroundColor: GymiesColors.darkBlue,
            padding: const EdgeInsets.symmetric(vertical: 14),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
          icon: const Icon(Icons.payments_rounded),
          label: Text(
            'Vraag nu uitbetaling aan',
            style: GoogleFonts.sora(fontWeight: FontWeight.w600),
          ),
        ),
        const SizedBox(height: 20),
        Row(
          children: [
            Container(
              width: 26, height: 26,
              decoration: BoxDecoration(color: GymiesColors.darkBlue.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(7)),
              child: const Icon(Icons.payments_rounded, size: 14, color: GymiesColors.darkBlue),
            ),
            const SizedBox(width: 10),
            Text('Uitbetalingen', style: GoogleFonts.sora(fontSize: 16, fontWeight: FontWeight.w700, color: GymiesColors.darkBlue)),
          ],
        ),
        const SizedBox(height: 8),
        ..._payouts.map(
          (e) => Container(
            margin: const EdgeInsets.only(bottom: 6),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 10, offset: const Offset(0, 2))],
            ),
            child: ListTile(
              title: Text(
                mapStr(e, ['status', 'state']).isNotEmpty
                    ? mapStr(e, ['status', 'state'])
                    : 'Payout',
                style: GoogleFonts.sora(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: GymiesColors.darkBlue,
                ),
              ),
              subtitle: Text(
                'Bedrag: ${_currency(mapPick(e, ['amount_cents', 'amountCents', 'amount']))}',
                style: GoogleFonts.sora(fontSize: 13),
              ),
            ),
          ),
        ),
        const SizedBox(height: 20),
        Row(
          children: [
            Container(
              width: 26, height: 26,
              decoration: BoxDecoration(color: GymiesColors.primary.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(7)),
              child: const Icon(Icons.calendar_month_rounded, size: 14, color: GymiesColors.darkBlue),
            ),
            const SizedBox(width: 10),
            Text('Payout kalender', style: GoogleFonts.sora(fontSize: 16, fontWeight: FontWeight.w700, color: GymiesColors.darkBlue)),
          ],
        ),
        const SizedBox(height: 8),
        ..._payoutCalendar.map(
          (e) => Container(
            margin: const EdgeInsets.only(bottom: 6),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 10, offset: const Offset(0, 2))],
            ),
            child: ListTile(
              title: Text(
                mapStr(e, ['date', 'scheduled_at']).isNotEmpty
                    ? mapStr(e, ['date', 'scheduled_at'])
                    : '-',
                style: GoogleFonts.sora(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: GymiesColors.darkBlue,
                ),
              ),
              subtitle: Text(
                mapStr(e, ['label', 'description', 'status']),
                style: GoogleFonts.sora(fontSize: 13),
              ),
            ),
          ),
        ),
      ],
    );
  }

  /// Toont uitsluitend het gemaskeerde IBAN (backend levert iban_masked / iban_last4).
  /// Toont nooit het volledige IBAN-nummer in de UI.
  String _maskedIban(Map<String, dynamic>? settings) {
    if (settings == null) return '-';
    final masked = settings['iban_masked']?.toString().trim() ?? '';
    if (masked.isNotEmpty) return masked;
    final last4 = settings['iban_last4']?.toString().trim() ?? '';
    if (last4.isNotEmpty) return 'IBAN •••• $last4';
    // Geen gemaskeerde versie beschikbaar: toon alleen of IBAN aanwezig is.
    final raw = settings['iban']?.toString().trim() ?? settings['iban_number']?.toString().trim() ?? '';
    if (raw.isNotEmpty) return 'IBAN ••••';
    return '-';
  }

  Widget _settingsTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 10, offset: const Offset(0, 2))],
          ),
          child: ListTile(
            title: Text(
              'Huidige payout settings',
              style: GoogleFonts.sora(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: GymiesColors.darkBlue,
              ),
            ),
            subtitle: Text(
              'Methode: ${mapStr(_payoutSettings, ['method', 'payout_method']).isNotEmpty ? mapStr(_payoutSettings, ['method', 'payout_method']) : '-'}\n'
              'IBAN: ${_maskedIban(_payoutSettings)}',
              style: GoogleFonts.sora(fontSize: 13),
            ),
            trailing: const Icon(Icons.edit_outlined),
            onTap: _editPayoutSettings,
          ),
        ),
      ],
    );
  }

  Widget _invoicesTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        FilledButton.icon(
          onPressed: _loadQuarterZipInfo,
          style: FilledButton.styleFrom(
            backgroundColor: GymiesColors.primary,
            foregroundColor: GymiesColors.darkBlue,
            padding: const EdgeInsets.symmetric(vertical: 14),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
          icon: const Icon(Icons.archive_outlined),
          label: Text(
            'Kwartaal ZIP export',
            style: GoogleFonts.sora(fontWeight: FontWeight.w600),
          ),
        ),
        const SizedBox(height: 16),
        ..._invoices.map(
          (e) => Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 10, offset: const Offset(0, 2))],
              ),
              child: ListTile(
                leading: Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: GymiesColors.primary.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(9),
                  ),
                  child: const Icon(Icons.receipt_outlined, size: 18, color: GymiesColors.darkBlue),
                ),
                title: Text(
                  mapStr(e, ['number', 'invoice_number']).isNotEmpty
                      ? mapStr(e, ['number', 'invoice_number'])
                      : 'Factuur',
                  style: GoogleFonts.sora(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: GymiesColors.darkBlue,
                  ),
                ),
                subtitle: Text(
                  '${mapStr(e, ['date', 'issued_at']).isNotEmpty ? mapStr(e, ['date', 'issued_at']) : '-'} · ${_currency(mapPick(e, ['total_cents', 'totalCents', 'total']))}',
                  style: GoogleFonts.sora(fontSize: 13),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _kvCard(String title, dynamic cents, {IconData? icon}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 10, offset: const Offset(0, 2))],
      ),
      child: Row(
        children: [
          if (icon != null) ...[
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: GymiesColors.primary.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, size: 16, color: GymiesColors.darkBlue),
            ),
            const SizedBox(width: 12),
          ],
          Expanded(
            child: Text(
              title,
              style: GoogleFonts.sora(
                fontSize: 14,
                color: Colors.grey.shade700,
              ),
            ),
          ),
          Text(
            _currency(cents),
            style: GoogleFonts.sora(
              fontSize: 18,
              fontWeight: FontWeight.w800,
              color: GymiesColors.darkBlue,
            ),
          ),
        ],
      ),
    );
  }
}

class _ForecastBarPoint {
  const _ForecastBarPoint({required this.label, required this.value});
  final String label;
  final double value;
}

class _ForecastBarChart extends StatelessWidget {
  const _ForecastBarChart({required this.points});
  final List<_ForecastBarPoint> points;

  @override
  Widget build(BuildContext context) {
    if (points.isEmpty) return const SizedBox.shrink();
    final maxVal =
        points.map((e) => e.value).reduce((a, b) => a > b ? a : b);
    final safeMax = maxVal <= 0 ? 1.0 : maxVal;
    return SizedBox(
      height: 140,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: points.map((p) {
          final normalized = (p.value / safeMax).clamp(0.08, 1.0);
          return Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 6),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Container(
                    height: 90 * normalized,
                    decoration: BoxDecoration(
                      color: GymiesColors.primary,
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    '€${p.value.toStringAsFixed(0)}',
                    style: GoogleFonts.sora(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                  Text(
                    p.label,
                    style: GoogleFonts.sora(fontSize: 10),
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}
