import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

import '../services/api_client.dart';
import '../services/gymies_api.dart';
import '../services/subscription_entitlements_service.dart';
import '../theme/gymies_theme.dart';
import '../utils/map_utils.dart';
import 'trainer_client_dossier_screen.dart';
import 'widgets/gymies_app_bar.dart';
import 'widgets/gymies_dialog.dart';
import 'widgets/gymies_section_header.dart';
import 'widgets/gymies_upgrade_prompt.dart';
import 'widgets/trainer_state_views.dart';
import '../utils/haptics.dart';

/// Klanten CRM-centrum: Overzicht, Inzichten (Pro), Analytics (Pro+), Communicatie (Pro+).
class TrainerClientsScreen extends StatefulWidget {
  const TrainerClientsScreen({
    super.key,
    this.onAvatarTap,
    this.avatarLabel,
  });

  final VoidCallback? onAvatarTap;
  final String? avatarLabel;

  @override
  State<TrainerClientsScreen> createState() => _TrainerClientsScreenState();
}

class _TrainerClientsScreenState extends State<TrainerClientsScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  // ── Overzicht data ──
  bool _clientsLoading = true;
  String? _clientsError;
  List<Map<String, dynamic>> _clients = [];
  String _searchQuery = '';

  // ── Inzichten data (Pro Hub) ──
  bool _insightsLoading = true;
  String? _insightsError;
  List<Map<String, dynamic>> _health = [];
  List<Map<String, dynamic>> _upsell = [];
  List<Map<String, dynamic>> _rebook = [];
  bool _insightsBusy = false;

  // ── Auto-Rebook settings ──
  bool _autoRebookEnabled = false;
  int _rebookIntervalDays = 7;
  bool _rebookSettingsLoading = false;
  List<Map<String, dynamic>> _packageExpiring = [];

  // ── Analytics data ──
  bool _analyticsLoading = true;
  String? _analyticsError;
  int _activeCount = 0;
  int _riskCount = 0;
  int _inactiveCount = 0;
  double _totalRevenue = 0;
  int _totalSessions = 0;
  List<Map<String, dynamic>> _analyticsClients = [];
  List<Map<String, dynamic>> _filteredAnalyticsClients = [];
  String _analyticsFilter = 'all';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _tabController.addListener(_onTabChanged);
    _loadClients();
  }

  @override
  void dispose() {
    _tabController.removeListener(_onTabChanged);
    _tabController.dispose();
    super.dispose();
  }

  void _onTabChanged() {
    if (!_tabController.indexIsChanging) return;
    final ent = context.read<SubscriptionEntitlementsService>();
    final tierLower = ent.tier?.toLowerCase() ?? 'starter';
    final isPro = tierLower.contains('pro') || tierLower == 'studio';
    final isProPlus = tierLower.contains('pro_plus') ||
        tierLower.contains('proplus') ||
        tierLower == 'studio';

    if (_tabController.index == 1 && isPro && _health.isEmpty && !_insightsLoading) {
      _loadInsights();
    }
    if (_tabController.index == 2 && isProPlus && _analyticsClients.isEmpty && !_analyticsLoading) {
      _loadAnalytics();
    }
  }

  // ── Load Clients (Overzicht) ──
  Future<void> _loadClients() async {
    setState(() {
      _clientsLoading = true;
      _clientsError = null;
    });
    try {
      final list = await context.read<GymiesApi>().getTrainerSleepingClients();
      if (!mounted) return;
      setState(() {
        _clients = list;
        _clientsLoading = false;
      });
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() {
        _clientsError = e.message;
        _clientsLoading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _clientsError = 'Kon klantenoverzicht niet laden.';
        _clientsLoading = false;
      });
    }
  }

  // ── Load Insights (Pro Hub data) ──
  Future<void> _loadInsights() async {
    setState(() {
      _insightsLoading = true;
      _insightsError = null;
    });
    try {
      final api = context.read<GymiesApi>();
      final results = await Future.wait([
        api.getTrainerClientHealthScores(),
        api.getTrainerUpsellSuggestions(),
        api.getTrainerRebookSuggestions(),
      ]);
      if (!mounted) return;
      setState(() {
        _health = (results[0] is List)
            ? List<Map<String, dynamic>>.from(results[0] as List)
            : <Map<String, dynamic>>[];
        _upsell = (results[1] is List)
            ? List<Map<String, dynamic>>.from(results[1] as List)
            : <Map<String, dynamic>>[];
        _rebook = (results[2] is List)
            ? List<Map<String, dynamic>>.from(results[2] as List)
            : <Map<String, dynamic>>[];
        _insightsLoading = false;
      });
      // Also load rebook settings & expiring packages
      _loadRebookSettings();
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() {
        _insightsError = e.message;
        _insightsLoading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _insightsError = 'Kon inzichten niet laden.';
        _insightsLoading = false;
      });
    }
  }

  // ── Load Analytics (Pro+) ──
  Future<void> _loadAnalytics() async {
    setState(() {
      _analyticsLoading = true;
      _analyticsError = null;
    });
    try {
      final data = await context.read<GymiesApi>().getClientAnalytics();
      if (!mounted) return;
      final summary = data['summary'] as Map<String, dynamic>? ?? {};
      final clientsRaw = data['clients'];
      final clients = (clientsRaw is List)
          ? List<Map<String, dynamic>>.from(
              clientsRaw.map((c) => c is Map<String, dynamic>
                  ? c
                  : (c is Map ? Map<String, dynamic>.from(c) : <String, dynamic>{})),
            )
          : <Map<String, dynamic>>[];
      setState(() {
        _activeCount = (summary['active'] as num?)?.toInt() ??
            (summary['active_count'] as num?)?.toInt() ?? 0;
        _riskCount = (summary['risk'] as num?)?.toInt() ??
            (summary['risk_count'] as num?)?.toInt() ??
            (summary['at_risk'] as num?)?.toInt() ?? 0;
        _inactiveCount = (summary['inactive'] as num?)?.toInt() ??
            (summary['inactive_count'] as num?)?.toInt() ?? 0;
        _totalRevenue = (summary['total_revenue'] as num?)?.toDouble() ??
            (summary['revenue'] as num?)?.toDouble() ?? 0;
        _totalSessions = (summary['total_sessions'] as num?)?.toInt() ??
            (summary['sessions'] as num?)?.toInt() ?? 0;
        _analyticsClients = clients;
        _applyAnalyticsFilter();
        _analyticsLoading = false;
      });
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() {
        _analyticsError = e.message;
        _analyticsLoading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _analyticsError = 'Kon analytics niet laden.';
        _analyticsLoading = false;
      });
    }
  }

  // ── Helpers ──
  void _applyAnalyticsFilter() {
    if (_analyticsFilter == 'all') {
      _filteredAnalyticsClients = List.from(_analyticsClients);
    } else {
      _filteredAnalyticsClients = _analyticsClients.where((c) {
        final status = mapStr(c, ['status', 'client_status']).toLowerCase();
        if (_analyticsFilter == 'active') return status == 'active' || status == 'actief';
        if (_analyticsFilter == 'risk') {
          return status == 'risk' || status == 'at_risk' || status == 'risico';
        }
        if (_analyticsFilter == 'inactive') return status == 'inactive' || status == 'inactief';
        return true;
      }).toList();
    }
  }

  void _setAnalyticsFilter(String filter) {
    setState(() {
      _analyticsFilter = filter;
      _applyAnalyticsFilter();
    });
  }

  Color _healthColor(int score) {
    if (score >= 75) return Colors.green.shade700;
    if (score >= 50) return Colors.orange.shade800;
    return Colors.red.shade700;
  }

  Color _statusColor(String status) {
    final s = status.toLowerCase();
    if (s == 'active' || s == 'actief') return Colors.green.shade700;
    if (s == 'new' || s == 'nieuw') return Colors.blue.shade700;
    if (s == 'risk' || s == 'at_risk' || s == 'risico') return Colors.orange.shade800;
    if (s == 'inactive' || s == 'inactief') return Colors.red.shade700;
    return GymiesColors.darkBlue;
  }

  String _statusLabel(String status) {
    final s = status.toLowerCase();
    if (s == 'active' || s == 'actief') return 'Actief';
    if (s == 'risk' || s == 'at_risk' || s == 'risico') return 'Risico';
    if (s == 'inactive' || s == 'inactief') return 'Inactief';
    if (s == 'new' || s == 'nieuw') return 'Nieuw';
    return status;
  }

  String _formatLastSession(String dateStr) {
    final dt = DateTime.tryParse(dateStr);
    if (dt == null) return dateStr;
    final diff = DateTime.now().difference(dt);
    if (diff.inDays == 0) return 'Vandaag';
    if (diff.inDays == 1) return 'Gisteren';
    if (diff.inDays < 7) return '${diff.inDays} dagen geleden';
    if (diff.inDays < 30) return '${(diff.inDays / 7).floor()} weken geleden';
    return '${(diff.inDays / 30).floor()} maanden geleden';
  }

  Future<void> _openClient(Map<String, dynamic> client) async {
    Haptics.selection();
    final clientId = mapStr(client, ['client_user_id', 'clientUserId', 'id']);
    if (clientId.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Klant-ID ontbreekt.'), backgroundColor: Colors.red),
      );
      return;
    }
    final name = mapStr(client, ['name', 'full_name']).isNotEmpty
        ? mapStr(client, ['name', 'full_name'])
        : 'Klant';
    final email = mapStr(client, ['email', 'email_address']);
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => TrainerClientDossierScreen(
          clientUserId: clientId,
          clientName: name,
          clientEmail: email,
        ),
      ),
    );
  }

  Future<void> _sendUpsell(Map<String, dynamic> item) async {
    if (_insightsBusy) return;
    Haptics.light();
    final suggestionId = mapStr(item, ['id', 'suggestion_id', 'suggestionId']).trim();
    if (suggestionId.isEmpty) return;
    setState(() => _insightsBusy = true);
    try {
      await context.read<GymiesApi>().sendTrainerUpsellSuggestion(
        suggestionId: suggestionId,
        clientUserId: mapStr(item, ['client_user_id', 'clientUserId']),
        packageId: mapStr(item, ['package_id', 'packageId']),
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Upsell voorstel verstuurd'), backgroundColor: GymiesColors.darkBlue),
      );
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.message), backgroundColor: Colors.red),
      );
    } finally {
      if (mounted) setState(() => _insightsBusy = false);
    }
  }

  Future<void> _sendRebook(Map<String, dynamic> item) async {
    if (_insightsBusy) return;
    Haptics.light();
    final clientUserId = mapStr(item, ['id', 'client_user_id', 'clientUserId']).trim();
    if (clientUserId.isEmpty) return;
    setState(() => _insightsBusy = true);
    try {
      await context.read<GymiesApi>().sendTrainerBulkMessage(
        clientUserIds: [clientUserId],
        body: 'We missen je! Plan je volgende sessie via Mijn afspraken in de app.',
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('We missen je-bericht verstuurd'), backgroundColor: GymiesColors.darkBlue),
      );
      _loadInsights();
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.message), backgroundColor: Colors.red),
      );
    } finally {
      if (mounted) setState(() => _insightsBusy = false);
    }
  }

  // ── Auto-Rebook settings ──
  Future<void> _loadRebookSettings() async {
    try {
      final api = context.read<GymiesApi>();
      final settings = await api.getTrainerSettings();
      if (!mounted) return;
      setState(() {
        _autoRebookEnabled = settings['auto_rebook_enabled'] == true;
        _rebookIntervalDays = (settings['rebook_interval_days'] as num?)?.toInt() ?? 7;
      });
    } catch (_) {
      // Graceful: defaults remain
    }
    // Load expiring packages
    try {
      final api = context.read<GymiesApi>();
      final expiring = await api.getTrainerPackageExpiringSoon();
      if (!mounted) return;
      setState(() {
        _packageExpiring = (expiring is List)
            ? List<Map<String, dynamic>>.from(expiring)
            : <Map<String, dynamic>>[];
      });
    } catch (_) {
      // Graceful: empty list
    }
  }

  Future<void> _toggleAutoRebook(bool value) async {
    Haptics.light();
    setState(() {
      _autoRebookEnabled = value;
      _rebookSettingsLoading = true;
    });
    try {
      await context.read<GymiesApi>().updateTrainerSettings({
        'auto_rebook_enabled': value,
        'rebook_interval_days': _rebookIntervalDays,
      });
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(value
              ? 'Auto-herboekingen ingeschakeld'
              : 'Auto-herboekingen uitgeschakeld'),
          backgroundColor: GymiesColors.darkBlue,
        ),
      );
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() => _autoRebookEnabled = !value);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.message), backgroundColor: Colors.red),
      );
    } catch (_) {
      if (mounted) setState(() => _autoRebookEnabled = !value);
    } finally {
      if (mounted) setState(() => _rebookSettingsLoading = false);
    }
  }

  Future<void> _updateRebookInterval(int days) async {
    Haptics.selection();
    final oldDays = _rebookIntervalDays;
    setState(() {
      _rebookIntervalDays = days;
      _rebookSettingsLoading = true;
    });
    try {
      await context.read<GymiesApi>().updateTrainerSettings({
        'auto_rebook_enabled': _autoRebookEnabled,
        'rebook_interval_days': days,
      });
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Interval bijgewerkt naar $days dagen'),
          backgroundColor: GymiesColors.darkBlue,
        ),
      );
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() => _rebookIntervalDays = oldDays);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.message), backgroundColor: Colors.red),
      );
    } catch (_) {
      if (mounted) setState(() => _rebookIntervalDays = oldDays);
    } finally {
      if (mounted) setState(() => _rebookSettingsLoading = false);
    }
  }

  void _showIntervalPicker() {
    Haptics.selection();
    final options = [3, 5, 7, 10, 14, 21, 30];
    showDialog<void>(
      context: context,
      builder: (ctx) => GymiesDialog(
        title: 'Herboek-interval',
        headerIcon: Icons.timer_outlined,
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Na hoeveel dagen inactiviteit ontvangen klanten automatisch een herinnering?',
              style: GoogleFonts.sora(fontSize: 13, color: Colors.grey.shade600),
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: options.map((d) {
                final selected = d == _rebookIntervalDays;
                return ChoiceChip(
                  label: Text('$d dagen'),
                  selected: selected,
                  onSelected: (_) {
                    Navigator.of(ctx).pop();
                    _updateRebookInterval(d);
                  },
                  selectedColor: GymiesColors.primary.withValues(alpha: 0.25),
                  checkmarkColor: GymiesColors.darkBlue,
                  labelStyle: GoogleFonts.sora(
                    fontSize: 13,
                    fontWeight: selected ? FontWeight.w600 : FontWeight.w400,
                    color: selected ? GymiesColors.darkBlue : Colors.grey.shade700,
                  ),
                  side: BorderSide(
                    color: selected ? GymiesColors.primary : Colors.grey.shade300,
                  ),
                );
              }).toList(),
            ),
          ],
        ),
        actions: [
          GymiesDialogAction(label: 'Sluiten', returnValue: null),
        ],
      ),
    );
  }

  Future<void> _sendRebookAll() async {
    if (_insightsBusy || _rebook.isEmpty) return;
    Haptics.light();
    final confirm = await GymiesDialog.custom<bool>(
      context,
      title: 'Alle herinneringen versturen?',
      icon: Icons.send_rounded,
      content: Text(
        'Er ${_rebook.length == 1 ? 'wordt 1 bericht' : 'worden ${_rebook.length} berichten'} verstuurd naar inactieve klanten.',
        style: GoogleFonts.sora(fontSize: 14),
      ),
      actions: [
        GymiesDialogAction(label: 'Annuleren', returnValue: false),
        GymiesDialogAction(label: 'Versturen', isPrimary: true, returnValue: true),
      ],
    );
    if (confirm != true || !mounted) return;
    setState(() => _insightsBusy = true);
    try {
      final ids = _rebook
          .map((e) => mapStr(e, ['id', 'client_user_id', 'clientUserId']).trim())
          .where((e) => e.isNotEmpty)
          .toList();
      if (ids.isEmpty) return;
      await context.read<GymiesApi>().sendTrainerBulkMessage(
        clientUserIds: ids,
        body: 'We missen je! Plan je volgende sessie via Mijn afspraken in de app.',
      );
      if (!mounted) return;
      Haptics.success();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${ids.length} herinnering${ids.length == 1 ? '' : 'en'} verstuurd'),
          backgroundColor: GymiesColors.darkBlue,
        ),
      );
      _loadInsights();
    } on ApiException catch (e) {
      if (!mounted) return;
      Haptics.error();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.message), backgroundColor: Colors.red),
      );
    } finally {
      if (mounted) setState(() => _insightsBusy = false);
    }
  }

  Future<void> _bulkMessage() async {
    if (_clients.isEmpty) return;
    Haptics.selection();
    final controller = TextEditingController();
    await showDialog<void>(
      context: context,
      builder: (ctx) {
        var sending = false;
        return StatefulBuilder(
          builder: (ctx, setDialogState) => GymiesDialog(
            title: 'Bulk bericht',
            headerIcon: Icons.campaign_outlined,
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: controller,
                  maxLines: 4,
                  enabled: !sending,
                  decoration: const InputDecoration(labelText: 'Bericht'),
                ),
                if (sending) ...[
                  const SizedBox(height: 16),
                  const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)),
                      SizedBox(width: 12),
                      Text('Versturen…'),
                    ],
                  ),
                ],
              ],
            ),
            actions: [
              GymiesDialogAction(
                label: 'Annuleren',
                returnValue: null,
              ),
              GymiesDialogAction(
                label: sending ? 'Bezig…' : 'Versturen',
                isPrimary: true,
                onPressed: sending
                    ? null
                    : () async {
                        if (controller.text.trim().isEmpty) return;
                        final ids = _clients
                            .map((e) => mapStr(e, ['client_user_id', 'clientUserId', 'id']))
                            .where((e) => e.isNotEmpty)
                            .toList();
                        if (ids.isEmpty) return;
                        setDialogState(() => sending = true);
                        try {
                          await context.read<GymiesApi>().sendTrainerBulkMessage(
                            clientUserIds: ids,
                            body: controller.text.trim(),
                          );
                          if (ctx.mounted) Navigator.of(ctx).pop();
                          if (!mounted) return;
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Bulk bericht verstuurd'), backgroundColor: GymiesColors.darkBlue),
                          );
                        } on ApiException catch (e) {
                          if (ctx.mounted) setDialogState(() => sending = false);
                          if (!mounted) return;
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text(e.message), backgroundColor: Colors.red),
                          );
                        } catch (e) {
                          if (ctx.mounted) setDialogState(() => sending = false);
                          debugPrint('[TrainerClients] Bulk bericht fout: $e');
                        }
                      },
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _openPrioritySupportComposer() async {
    Haptics.selection();
    final issueCtrl = TextEditingController();
    final bookingCtrl = TextEditingController();
    final submit = await GymiesDialog.custom<bool>(
      context,
      title: 'Priority support lane',
      icon: Icons.priority_high_rounded,
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: issueCtrl,
            maxLines: 3,
            decoration: const InputDecoration(
              labelText: 'Issue',
              hintText: 'Beschrijf kort het urgente probleem',
            ),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: bookingCtrl,
            decoration: const InputDecoration(
              labelText: 'Booking reference (optioneel)',
            ),
          ),
        ],
      ),
      actions: [
        GymiesDialogAction(
          label: 'Annuleren',
          returnValue: false,
        ),
        GymiesDialogAction(
          label: 'Verstuur',
          isPrimary: true,
          returnValue: true,
        ),
      ],
    );
    if (submit != true || issueCtrl.text.trim().isEmpty) return;
    if (!mounted) return;
    try {
      await context.read<GymiesApi>().createSupportTicket(
        type: 'incident',
        subject: 'Priority support lane',
        message:
            'Priority issue: ${issueCtrl.text.trim()}\nBookingRef: ${bookingCtrl.text.trim().isEmpty ? '-' : bookingCtrl.text.trim()}\nSource: TrainerClients',
        bookingId: bookingCtrl.text.trim(),
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Priority support ticket verstuurd'), backgroundColor: GymiesColors.darkBlue),
      );
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.message), backgroundColor: Colors.red),
      );
    }
  }

  // ──────────────────────────────────────────────
  // BUILD
  // ──────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final ent = context.watch<SubscriptionEntitlementsService>();
    final tierLower = ent.tier?.toLowerCase() ?? 'starter';
    final isPro = tierLower.contains('pro') || tierLower == 'studio';
    final isProPlus = tierLower.contains('pro_plus') ||
        tierLower.contains('proplus') ||
        tierLower == 'studio';

    return Scaffold(
      backgroundColor: const Color(0xFFF7F8FA),
      appBar: GymiesAppBar(
        title: 'Klanten',
        onAvatarTap: widget.onAvatarTap,
        avatarLabel: widget.avatarLabel,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(48),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
            child: TabBar(
              controller: _tabController,
              indicator: BoxDecoration(
                color: GymiesColors.primary,
                borderRadius: BorderRadius.circular(20),
              ),
              indicatorSize: TabBarIndicatorSize.tab,
              dividerColor: Colors.transparent,
              labelColor: GymiesColors.darkBlue,
              unselectedLabelColor: Colors.white.withValues(alpha: 0.6),
              labelStyle: GoogleFonts.sora(
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
              unselectedLabelStyle: GoogleFonts.sora(
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
              splashBorderRadius: BorderRadius.circular(20),
              padding: EdgeInsets.zero,
              labelPadding: const EdgeInsets.symmetric(horizontal: 2),
              tabs: const [
                Tab(height: 32, child: Text('Overzicht', textAlign: TextAlign.center)),
                Tab(height: 32, child: Text('Inzichten', textAlign: TextAlign.center)),
                Tab(height: 32, child: Text('Analytics', textAlign: TextAlign.center)),
                Tab(height: 32, child: Text('Chat', textAlign: TextAlign.center)),
              ],
            ),
          ),
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildOverviewTab(),
          isPro
              ? _buildInsightsTab()
              : const GymiesUpgradePrompt(
                  icon: Icons.insights_rounded,
                  feature: 'Klantinzichten',
                  tier: 'Pro',
                  description: 'Zie welke klanten dreigen af te haken en krijg AI-suggesties voor upsells en herboekingen.',
                ),
          isProPlus
              ? _buildAnalyticsTab()
              : GymiesUpgradePrompt(
                  icon: Icons.analytics_outlined,
                  feature: 'Klant Analytics',
                  tier: isPro ? 'Pro+' : 'Pro',
                  description: 'Segmenteer je klanten op activiteit en omzet. Zie precies waar je groei zit.',
                ),
          isProPlus
              ? _buildCommunicationTab()
              : GymiesUpgradePrompt(
                  icon: Icons.campaign_outlined,
                  feature: 'Klant Communicatie',
                  tier: isPro ? 'Pro+' : 'Pro',
                  description: 'Stuur bulk berichten naar je klanten en gebruik de priority support lane.',
                ),
        ],
      ),
    );
  }

  // ── Tab 0: Overzicht ──
  Widget _buildOverviewTab() {
    return GymiesListBody(
      loading: _clientsLoading,
      error: _clientsError,
      onRefresh: _loadClients,
      child: Column(
        children: [
          // Zoekbalk
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.03),
                    blurRadius: 6,
                    offset: const Offset(0, 1),
                  ),
                ],
              ),
              child: TextField(
                onChanged: (v) => setState(() => _searchQuery = v.toLowerCase()),
                style: GoogleFonts.sora(fontSize: 13, color: GymiesColors.darkBlue),
                decoration: InputDecoration(
                  hintText: 'Zoek klant...',
                  hintStyle: GoogleFonts.sora(fontSize: 13, color: Colors.grey.shade400),
                  prefixIcon: Icon(Icons.search_rounded, color: Colors.grey.shade400, size: 20),
                  suffixIcon: Padding(
                    padding: const EdgeInsets.only(right: 12),
                    child: Text(
                      '${_filteredClients.length} klanten',
                      style: GoogleFonts.sora(fontSize: 11, color: Colors.grey.shade400),
                    ),
                  ),
                  suffixIconConstraints: const BoxConstraints(minWidth: 0, minHeight: 0),
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide(color: Colors.grey.shade100),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide(color: Colors.grey.shade100),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide(color: GymiesColors.primary, width: 1.5),
                  ),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                ),
              ),
            ),
          ),
          // Klantenlijst
          Expanded(
            child: _clients.isEmpty
                ? ListView(
                    children: const [
                      TrainerEmptyState(
                        icon: Icons.people_alt_outlined,
                        title: 'Geen klanten gevonden',
                        subtitle: 'Klanten verschijnen hier zodra ze een sessie boeken.',
                      ),
                    ],
                  )
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: _filteredClients.length,
                    itemBuilder: (_, i) {
                      final c = _filteredClients[i];
                      final name = mapStr(c, ['name', 'full_name']).isNotEmpty
                          ? mapStr(c, ['name', 'full_name'])
                          : 'Klant';
                      final email = mapStr(c, ['email', 'email_address']);
                      final sessionCount = mapInt(c, ['session_count', 'total_sessions', 'sessions']);
                      final status = mapStr(c, ['status', 'client_status']);
                      final statusClr = _statusColor(status);
                      final initials = name.length >= 2
                          ? '${name[0]}${name.split(' ').length > 1 ? name.split(' ').last[0] : name[1]}'.toUpperCase()
                          : (name.isNotEmpty ? name[0].toUpperCase() : '?');
                      final lastSession = mapStr(c, ['last_session_at', 'lastSessionAt', 'last_active']);
                      final lastLabel = lastSession.isNotEmpty
                          ? _formatLastSession(lastSession)
                          : (sessionCount > 0 ? '$sessionCount sessies' : 'Geen sessies');

                      return Container(
                        margin: const EdgeInsets.only(bottom: 10),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(14),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.04),
                              blurRadius: 10,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(14),
                          onTap: () => _openClient(c),
                          child: Padding(
                            padding: const EdgeInsets.all(14),
                            child: Row(
                              children: [
                                // ── Square avatar with status color ──
                                Container(
                                  width: 42,
                                  height: 42,
                                  decoration: BoxDecoration(
                                    color: statusClr.withValues(alpha: 0.1),
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: Center(
                                    child: Text(
                                      initials,
                                      style: GoogleFonts.sora(
                                        fontWeight: FontWeight.w700,
                                        color: statusClr,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          Flexible(
                                            child: Text(
                                              name,
                                              style: GoogleFonts.sora(
                                                fontWeight: FontWeight.w600,
                                                fontSize: 14,
                                                color: GymiesColors.darkBlue,
                                              ),
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                          if (status.isNotEmpty) ...[
                                            const SizedBox(width: 8),
                                            Container(
                                              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                                              decoration: BoxDecoration(
                                                color: statusClr.withValues(alpha: 0.08),
                                                borderRadius: BorderRadius.circular(10),
                                              ),
                                              child: Text(
                                                _statusLabel(status),
                                                style: GoogleFonts.sora(
                                                  fontSize: 10,
                                                  fontWeight: FontWeight.w600,
                                                  color: statusClr,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ],
                                      ),
                                      const SizedBox(height: 3),
                                      Text(
                                        '$sessionCount sessies · $lastLabel',
                                        style: GoogleFonts.sora(
                                          fontSize: 12,
                                          color: Colors.grey.shade500,
                                        ),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ],
                                  ),
                                ),
                                Icon(Icons.chevron_right_rounded, color: Colors.grey.shade300, size: 20),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  List<Map<String, dynamic>> get _filteredClients {
    if (_searchQuery.isEmpty) return _clients;
    return _clients.where((c) {
      final name = mapStr(c, ['name', 'full_name']).toLowerCase();
      return name.contains(_searchQuery);
    }).toList();
  }

  // ── Tab 1: Inzichten (Pro Hub content) ──
  Widget _buildInsightsTab() {
    if (_insightsLoading && _health.isEmpty) {
      // Eerste keer laden
      if (_health.isEmpty && _upsell.isEmpty && _rebook.isEmpty) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted && _insightsLoading && _health.isEmpty) _loadInsights();
        });
      }
      return const TrainerLoadingView();
    }
    return GymiesListBody(
      loading: _insightsLoading,
      error: _insightsError,
      onRefresh: _loadInsights,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // ── Health Scores ──
          const GymiesSectionHeader('Health Scores'),
          if (_health.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16),
              child: Text('Nog geen health score data beschikbaar.',
                style: GoogleFonts.sora(fontSize: 13, color: Colors.grey.shade600)),
            )
          else
            ..._health.map((item) {
              final name = mapStr(item, ['client_name', 'name', 'full_name']).isEmpty
                  ? 'Klant'
                  : mapStr(item, ['client_name', 'name', 'full_name']);
              final score = mapInt(item, ['health_score', 'score']);
              final retentionRisk = mapStr(item, ['retention_risk', 'risk_label', 'risk']);
              final noShowRisk = mapStr(item, ['no_show_risk', 'noshow_risk']);
              return Card(
                elevation: 0,
                margin: const EdgeInsets.only(bottom: 8),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: BorderSide(color: Colors.grey.shade200),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Row(
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: _healthColor(score).withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Center(
                          child: Text('$score',
                            style: GoogleFonts.sora(color: _healthColor(score), fontWeight: FontWeight.w700, fontSize: 14)),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(name, style: GoogleFonts.sora(fontWeight: FontWeight.w600, fontSize: 14)),
                            const SizedBox(height: 2),
                            Text(
                              'Retention: ${retentionRisk.isEmpty ? '-' : retentionRisk} · No-show: ${noShowRisk.isEmpty ? '-' : noShowRisk}',
                              style: GoogleFonts.sora(fontSize: 12, color: Colors.grey.shade600),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
          const SizedBox(height: 20),

          // ── Upsell Suggesties ──
          const GymiesSectionHeader('Upsell suggesties'),
          if (_upsell.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16),
              child: Text('Nog geen upsell suggesties beschikbaar.',
                style: GoogleFonts.sora(fontSize: 13, color: Colors.grey.shade600)),
            )
          else
            ..._upsell.map((item) {
              final name = mapStr(item, ['client_name', 'name']).isEmpty
                  ? 'Klant'
                  : mapStr(item, ['client_name', 'name']);
              final reason = mapStr(item, ['reason', 'explanation']);
              final packageName = mapStr(item, ['package_name', 'offer', 'target_package']);
              return Card(
                elevation: 0,
                margin: const EdgeInsets.only(bottom: 8),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: BorderSide(color: Colors.grey.shade200),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Row(
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: GymiesColors.primary.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(Icons.trending_up_rounded, color: GymiesColors.darkBlue, size: 20),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(name, style: GoogleFonts.sora(fontWeight: FontWeight.w600, fontSize: 14)),
                            const SizedBox(height: 2),
                            Text(
                              packageName.isEmpty ? 'Aanbeveling: pakket-upgrade' : 'Aanbeveling: $packageName',
                              style: GoogleFonts.sora(fontSize: 12, color: Colors.grey.shade600),
                            ),
                            if (reason.isNotEmpty) ...[
                              const SizedBox(height: 2),
                              Text(reason, style: GoogleFonts.sora(fontSize: 12, color: Colors.grey.shade500)),
                            ],
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      SizedBox(
                        height: 36,
                        child: FilledButton.icon(
                          onPressed: _insightsBusy ? null : () => _sendUpsell(item),
                          style: FilledButton.styleFrom(
                            backgroundColor: GymiesColors.primary,
                            foregroundColor: GymiesColors.darkBlue,
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            textStyle: GoogleFonts.sora(fontSize: 12, fontWeight: FontWeight.w600),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                          ),
                          icon: const Icon(Icons.send_rounded, size: 16),
                          label: const Text('Stuur'),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
          const SizedBox(height: 20),

          // ── Smart Rebook ──
          const GymiesSectionHeader('Smart Rebook'),

          // Auto-rebook settings card
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
              side: BorderSide(color: Colors.grey.shade200),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: GymiesColors.primary.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(Icons.autorenew_rounded, color: GymiesColors.darkBlue, size: 20),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Auto-herboekingen',
                              style: GoogleFonts.sora(fontWeight: FontWeight.w600, fontSize: 15)),
                            const SizedBox(height: 2),
                            Text(
                              _autoRebookEnabled
                                  ? 'Klanten krijgen automatisch een herinnering na $_rebookIntervalDays dagen inactiviteit'
                                  : 'Schakel in om automatisch herinneringen te sturen',
                              style: GoogleFonts.sora(fontSize: 12, color: Colors.grey.shade600),
                            ),
                          ],
                        ),
                      ),
                      if (_rebookSettingsLoading)
                        const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                      else
                        Switch.adaptive(
                          value: _autoRebookEnabled,
                          onChanged: _toggleAutoRebook,
                          activeColor: GymiesColors.primary,
                          activeTrackColor: GymiesColors.primary.withValues(alpha: 0.3),
                        ),
                    ],
                  ),
                  if (_autoRebookEnabled) ...[
                    const SizedBox(height: 12),
                    const Divider(height: 1),
                    const SizedBox(height: 12),
                    InkWell(
                      borderRadius: BorderRadius.circular(12),
                      onTap: _showIntervalPicker,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade50,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.grey.shade200),
                        ),
                        child: Row(
                          children: [
                            Icon(Icons.timer_outlined, size: 18, color: Colors.grey.shade600),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text('Interval: $_rebookIntervalDays dagen',
                                style: GoogleFonts.sora(fontSize: 13, fontWeight: FontWeight.w500)),
                            ),
                            Icon(Icons.chevron_right, size: 18, color: Colors.grey.shade400),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      decoration: BoxDecoration(
                        color: Colors.green.shade50,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.green.shade200),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.check_circle_outline, size: 18, color: Colors.green.shade700),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              'Berichten worden automatisch verstuurd. Je kunt dit altijd uitschakelen.',
                              style: GoogleFonts.sora(fontSize: 12, color: Colors.green.shade700),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          // ── Pakket verloop alerts ──
          if (_packageExpiring.isNotEmpty) ...[
            Row(
              children: [
                Icon(Icons.inventory_2_outlined, size: 18, color: Colors.orange.shade800),
                const SizedBox(width: 8),
                Text('Pakketten bijna verlopen',
                  style: GoogleFonts.sora(fontWeight: FontWeight.w600, fontSize: 14, color: Colors.orange.shade800)),
              ],
            ),
            const SizedBox(height: 8),
            ..._packageExpiring.map((pkg) {
              final clientName = mapStr(pkg, ['client_name', 'name']).isEmpty
                  ? 'Klant'
                  : mapStr(pkg, ['client_name', 'name']);
              final packageName = mapStr(pkg, ['package_name', 'packageName']);
              final daysLeft = mapInt(pkg, ['days_remaining', 'daysRemaining', 'days_left']);
              final sessionsLeft = mapInt(pkg, ['sessions_remaining', 'sessionsRemaining']);
              return Card(
                elevation: 0,
                margin: const EdgeInsets.only(bottom: 8),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: BorderSide(color: Colors.orange.shade200),
                ),
                color: Colors.orange.shade50,
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Row(
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: Colors.orange.shade100,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Center(
                          child: Text(
                            clientName.isNotEmpty ? clientName[0].toUpperCase() : '?',
                            style: GoogleFonts.sora(fontWeight: FontWeight.w700, fontSize: 16, color: Colors.orange.shade800),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(clientName, style: GoogleFonts.sora(fontWeight: FontWeight.w600, fontSize: 14)),
                            const SizedBox(height: 2),
                            Text(
                              packageName.isNotEmpty
                                  ? '$packageName · ${sessionsLeft > 0 ? '$sessionsLeft sessies over' : 'Bijna op'}'
                                  : 'Pakket bijna verlopen',
                              style: GoogleFonts.sora(fontSize: 12, color: Colors.grey.shade600),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: daysLeft <= 3 ? Colors.red.shade100 : Colors.orange.shade100,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          daysLeft <= 0 ? 'Verlopen' : '$daysLeft d',
                          style: GoogleFonts.sora(
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            color: daysLeft <= 3 ? Colors.red.shade800 : Colors.orange.shade800,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
            const SizedBox(height: 16),
          ],

          // ── Inactieve klanten ──
          Row(
            children: [
              Icon(Icons.people_outline_rounded, size: 18, color: GymiesColors.darkBlue),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Inactieve klanten (${_rebook.length})',
                  style: GoogleFonts.sora(fontWeight: FontWeight.w600, fontSize: 14),
                ),
              ),
              if (_rebook.length > 1)
                TextButton.icon(
                  onPressed: _insightsBusy ? null : _sendRebookAll,
                  icon: const Icon(Icons.send_rounded, size: 16),
                  label: Text('Alles versturen', style: GoogleFonts.sora(fontSize: 12)),
                  style: TextButton.styleFrom(
                    foregroundColor: GymiesColors.darkBlue,
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 8),
          if (_rebook.isEmpty)
            Card(
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
                side: BorderSide(color: Colors.grey.shade200),
              ),
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  children: [
                    Icon(Icons.check_circle_outline, size: 40, color: Colors.green.shade400),
                    const SizedBox(height: 12),
                    Text('Alle klanten zijn actief!',
                      style: GoogleFonts.sora(fontWeight: FontWeight.w600, fontSize: 15)),
                    const SizedBox(height: 4),
                    Text(
                      'Klanten verschijnen hier als ze langer dan $_rebookIntervalDays dagen geen sessie hadden.',
                      style: GoogleFonts.sora(fontSize: 13, color: Colors.grey.shade600),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            )
          else
            ..._rebook.map((item) {
              final name = mapStr(item, ['client_name', 'name']).isEmpty
                  ? 'Klant'
                  : mapStr(item, ['client_name', 'name']);
              final daysSince = mapInt(item, ['days_since_last', 'daysSinceLast']);
              final email = mapStr(item, ['email', 'client_email']);
              return Card(
                elevation: 0,
                margin: const EdgeInsets.only(bottom: 8),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: BorderSide(color: Colors.grey.shade200),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Row(
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: GymiesColors.primary.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Center(
                          child: Text(
                            name.isNotEmpty ? name[0].toUpperCase() : '?',
                            style: GoogleFonts.sora(fontWeight: FontWeight.w700, fontSize: 16, color: GymiesColors.darkBlue),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Flexible(
                                  child: Text(name,
                                    style: GoogleFonts.sora(fontWeight: FontWeight.w600, fontSize: 14),
                                    overflow: TextOverflow.ellipsis),
                                ),
                                const SizedBox(width: 8),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: daysSince >= 14
                                        ? Colors.red.shade100
                                        : Colors.orange.shade100,
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Text(
                                    daysSince > 0
                                        ? '$daysSince d'
                                        : '7+ d',
                                    style: GoogleFonts.sora(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w700,
                                      color: daysSince >= 14
                                          ? Colors.red.shade800
                                          : Colors.orange.shade800,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 2),
                            Text(
                              daysSince > 0
                                  ? '${daysSince == 1 ? '1 dag' : '$daysSince dagen'} sinds laatste sessie'
                                  : 'Langer dan 7 dagen inactief',
                              style: GoogleFonts.sora(fontSize: 12, color: Colors.grey.shade600),
                            ),
                            if (email.isNotEmpty)
                              Text(email,
                                style: GoogleFonts.sora(fontSize: 11, color: Colors.grey.shade500),
                                overflow: TextOverflow.ellipsis),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      SizedBox(
                        height: 36,
                        child: FilledButton.icon(
                          onPressed: _insightsBusy ? null : () => _sendRebook(item),
                          style: FilledButton.styleFrom(
                            backgroundColor: GymiesColors.primary,
                            foregroundColor: GymiesColors.darkBlue,
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            textStyle: GoogleFonts.sora(fontSize: 12, fontWeight: FontWeight.w600),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                          ),
                          icon: const Icon(Icons.favorite_rounded, size: 16),
                          label: const Text('Herinner'),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
          const SizedBox(height: 32),
        ],
      ),
    );
  }

  // ── Tab 2: Analytics (Pro+) ──
  Widget _buildAnalyticsTab() {
    if (_analyticsLoading && _analyticsClients.isEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && _analyticsLoading && _analyticsClients.isEmpty) _loadAnalytics();
      });
      return const TrainerLoadingView();
    }
    return GymiesListBody(
      loading: _analyticsLoading,
      error: _analyticsError,
      onRefresh: _loadAnalytics,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Summary cards
          Row(
            children: [
              Expanded(child: _SummaryCard(label: 'Actief', value: '$_activeCount', color: Colors.green.shade700, icon: Icons.person_rounded)),
              const SizedBox(width: 10),
              Expanded(child: _SummaryCard(label: 'Risico', value: '$_riskCount', color: Colors.orange.shade800, icon: Icons.warning_amber_rounded)),
              const SizedBox(width: 10),
              Expanded(child: _SummaryCard(label: 'Inactief', value: '$_inactiveCount', color: Colors.red.shade700, icon: Icons.person_off_rounded)),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: _SummaryCard(label: 'Sessies', value: '$_totalSessions', color: GymiesColors.darkBlue, icon: Icons.fitness_center_rounded)),
              const SizedBox(width: 10),
              Expanded(child: _SummaryCard(label: 'Omzet', value: '€${_totalRevenue.toStringAsFixed(0)}', color: GymiesColors.darkBlue, icon: Icons.euro_rounded)),
            ],
          ),
          const SizedBox(height: 20),

          // Filter chips
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                _filterChip('Alle', 'all'),
                const SizedBox(width: 8),
                _filterChip('Actief', 'active'),
                const SizedBox(width: 8),
                _filterChip('Risico', 'risk'),
                const SizedBox(width: 8),
                _filterChip('Inactief', 'inactive'),
              ],
            ),
          ),
          const SizedBox(height: 16),

          Text(
            '${_filteredAnalyticsClients.length} klant${_filteredAnalyticsClients.length == 1 ? '' : 'en'}',
            style: TextStyle(fontSize: 13, color: Colors.grey.shade600, fontWeight: FontWeight.w500),
          ),
          const SizedBox(height: 8),

          if (_filteredAnalyticsClients.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 32),
              child: Center(
                child: Text('Geen klanten gevonden voor dit filter.', style: TextStyle(color: Colors.grey.shade500)),
              ),
            )
          else
            ..._filteredAnalyticsClients.map((client) {
              final name = mapStr(client, ['name', 'client_name', 'full_name']);
              final status = mapStr(client, ['status', 'client_status']);
              final sessions = mapInt(client, ['session_count', 'sessions', 'total_sessions']);
              final revenue = (client['revenue'] as num?)?.toDouble() ??
                  (client['total_revenue'] as num?)?.toDouble() ?? 0;
              final lastSession = mapStr(client, ['last_session_at', 'last_session', 'lastSessionAt']);
              return Card(
                margin: const EdgeInsets.only(bottom: 8),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: _statusColor(status).withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Center(
                          child: Text(
                            name.isNotEmpty ? name[0].toUpperCase() : '?',
                            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16, color: _statusColor(status)),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Flexible(
                                  child: Text(
                                    name.isNotEmpty ? name : 'Klant',
                                    style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: _statusColor(status).withValues(alpha: 0.12),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Text(
                                    _statusLabel(status),
                                    style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: _statusColor(status)),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 4),
                            Text(
                              '$sessions sessies · €${revenue.toStringAsFixed(0)}',
                              style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                            ),
                            if (lastSession.isNotEmpty)
                              Padding(
                                padding: const EdgeInsets.only(top: 2),
                                child: Text('Laatst: $lastSession', style: TextStyle(fontSize: 11, color: Colors.grey.shade500)),
                              ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
          const SizedBox(height: 32),
        ],
      ),
    );
  }

  Widget _filterChip(String label, String value) {
    final selected = _analyticsFilter == value;
    return FilterChip(
      label: Text(label),
      selected: selected,
      onSelected: (_) {
        Haptics.selection();
        _setAnalyticsFilter(value);
      },
      selectedColor: GymiesColors.primary.withValues(alpha: 0.25),
      checkmarkColor: GymiesColors.darkBlue,
      labelStyle: TextStyle(
        fontWeight: selected ? FontWeight.w600 : FontWeight.w400,
        color: selected ? GymiesColors.darkBlue : Colors.grey.shade700,
        fontSize: 13,
      ),
      side: BorderSide(color: selected ? GymiesColors.primary : Colors.grey.shade300),
    );
  }

  // ── Tab 3: Communicatie (Pro+) ──
  Widget _buildCommunicationTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Bulk bericht
        const GymiesSectionHeader('Bulk bericht'),
        Card(
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: BorderSide(color: Colors.grey.shade200),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: GymiesColors.primary.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(Icons.campaign_outlined, color: GymiesColors.darkBlue, size: 20),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Bulk bericht', style: GoogleFonts.sora(fontWeight: FontWeight.w600, fontSize: 15)),
                          const SizedBox(height: 2),
                          Text(
                            'Stuur een bericht naar al je klanten tegelijk.',
                            style: GoogleFonts.sora(fontSize: 12, color: Colors.grey.shade600),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: _bulkMessage,
                    style: FilledButton.styleFrom(
                      backgroundColor: GymiesColors.primary,
                      foregroundColor: GymiesColors.darkBlue,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      textStyle: GoogleFonts.sora(fontSize: 14, fontWeight: FontWeight.w600),
                    ),
                    icon: const Icon(Icons.send_rounded),
                    label: const Text('Bulk bericht versturen'),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 20),

        // Priority support
        const GymiesSectionHeader('Priority support lane'),
        Card(
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: BorderSide(color: Colors.grey.shade200),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.red.shade50,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Icon(Icons.priority_high_rounded, color: Colors.red.shade700, size: 20),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Priority support', style: GoogleFonts.sora(fontWeight: FontWeight.w600, fontSize: 15)),
                          const SizedBox(height: 2),
                          Text(
                            'Voor urgente operationele issues met contextpakket.',
                            style: GoogleFonts.sora(fontSize: 12, color: Colors.grey.shade600),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: _openPrioritySupportComposer,
                    style: FilledButton.styleFrom(
                      backgroundColor: GymiesColors.darkBlue,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      textStyle: GoogleFonts.sora(fontSize: 14, fontWeight: FontWeight.w600),
                    ),
                    icon: const Icon(Icons.support_agent_rounded),
                    label: const Text('Open priority lane'),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 32),
      ],
    );
  }
}

// ── Summary Card (Analytics tab) ──
class _SummaryCard extends StatelessWidget {
  const _SummaryCard({
    required this.label,
    required this.value,
    required this.color,
    required this.icon,
  });

  final String label;
  final String value;
  final Color color;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: Colors.grey.shade200),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
        child: Column(
          children: [
            Icon(icon, color: color, size: 22),
            const SizedBox(height: 6),
            Text(
              value,
              style: GoogleFonts.sora(fontSize: 20, fontWeight: FontWeight.w700, color: color),
            ),
            const SizedBox(height: 2),
            Text(label, style: TextStyle(fontSize: 11, color: Colors.grey.shade600, fontWeight: FontWeight.w500)),
          ],
        ),
      ),
    );
  }
}
