import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../config/timing_constants.dart';
import '../theme/gymies_theme.dart';
import '../utils/haptics.dart';
import '../utils/map_utils.dart';
import '../models/booking.dart';
import '../models/trainer_summary.dart';
import '../services/auth_service.dart';
import '../services/gymies_api.dart';
import '../services/notification_realtime_service.dart';
import '../services/api_client.dart';
import '../services/action_retry_queue_service.dart';
import '../services/subscription_entitlements_service.dart';
import 'login_register_screen.dart';
import 'trainer_sessions_screen.dart';
import 'trainer_income_screen.dart';
import 'trainer_notifications_screen.dart';
import 'trainer_onboarding_screen.dart';
import 'client_support_screen.dart';
import 'trainer_check_in_scanner_screen.dart';
import 'widgets/gymies_app_bar.dart';
import 'widgets/trainer_state_views.dart';

/// Trainer-dashboard met overzicht en hamburgermenu.
class TrainerDashboardScreen extends StatefulWidget {
  const TrainerDashboardScreen({
    super.key,
    this.onAvatarTap,
    this.avatarLabel,
  });

  final VoidCallback? onAvatarTap;
  final String? avatarLabel;

  @override
  State<TrainerDashboardScreen> createState() => _TrainerDashboardScreenState();
}

class _TrainerDashboardScreenState extends State<TrainerDashboardScreen>
    with WidgetsBindingObserver, TickerProviderStateMixin {
  TrainerSummary? _summary;
  List<Map<String, dynamic>> _recentNotifications = [];
  bool _loading = true;
  String? _error;
  bool _onboardingCompleted = true;
  bool _onboardingBannerDismissed = false; // Gebruiker heeft "Later" geklikt
  int _queuePendingCount = 0;
  int _queueFailedCount = 0;
  int _queueHighRetryCount = 0;
  bool _queueFlushing = false;
  Timer? _checkInWindowTimer;
  bool _hasGymAccess = false;
  late AnimationController _staggerController;
  bool _hasAnimated = false;

  NotificationRealtimeService? _realtime({bool listen = false}) {
    try {
      return Provider.of<NotificationRealtimeService>(context, listen: listen);
    } catch (_) {
      return null;
    }
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _staggerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );
    _load();
    _startCheckInTimer();
  }

  void _startCheckInTimer() {
    _checkInWindowTimer?.cancel();
    _checkInWindowTimer = Timer.periodic(TimingConstants.checkInTimerInterval, (_) {
      if (!mounted) return;
      setState(() {}); // Herlaad build voor QR-knop zichtbaarheid
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive) {
      _checkInWindowTimer?.cancel();
    } else if (state == AppLifecycleState.resumed) {
      _startCheckInTimer();
      if (mounted) _load();
    }
  }

  /// Stagger animation helper: creates a curved interval for item at [index].
  Animation<double> _staggerAnimation(int index, {int total = 6}) {
    final start = (index / total).clamp(0.0, 1.0);
    final end = ((index + 1.5) / total).clamp(0.0, 1.0);
    return CurvedAnimation(
      parent: _staggerController,
      curve: Interval(start, end, curve: Curves.easeOut),
    );
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _checkInWindowTimer?.cancel();
    _staggerController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    if (!mounted) return;
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final auth = context.read<AuthService>();
      final api = context.read<GymiesApi>();
      final apiClient = context.read<ApiClient>();
      if (kDebugMode) {
        debugPrint('[TrainerDashboard] _load start | isLoggedIn=${auth.isLoggedIn} tokenLen=${auth.token?.length ?? 0} apiClientToken=${apiClient.authToken?.length ?? 0}');
      }
      if (auth.isLoggedIn && auth.token != null && auth.token!.isNotEmpty) {
        apiClient.setAuthToken(auth.token);
        if (kDebugMode) debugPrint('[TrainerDashboard] setAuthToken called – apiClient heeft nu ${apiClient.authToken?.length ?? 0} chars');
      } else if (kDebugMode) {
        debugPrint('[TrainerDashboard] GEEN setAuthToken – auth.token is leeg of null');
      }
      final entitlements = context.read<SubscriptionEntitlementsService>();
      if (kDebugMode) debugPrint('[TrainerDashboard] GET trainer/summary...');
      final summary = await api.getTrainerSummary();
      if (kDebugMode) debugPrint('[TrainerDashboard] getTrainerSummary OK');
      await entitlements.load();
      final tier = entitlements.tier?.toLowerCase() ?? '';
      bool hasGymAccess = entitlements.suiteEnabled || tier == 'studio' || tier == 'elite';
      if (!hasGymAccess) {
        try {
          await api.getGymMembership();
          hasGymAccess = true;
        } on ApiException catch (e) {
          if (e.statusCode == 401) rethrow;
        } catch (e) {
          debugPrint('[TrainerDashboard] Gym membership check fout: $e');
        }
      }
      int unread = 0;
      List<Map<String, dynamic>> notifications = const [];
      int queuePending = 0;
      int queueFailed = 0;
      int queueHighRetry = 0;
      try {
        unread = await api.getNotificationUnreadCount();
      } on ApiException catch (e) {
        if (e.statusCode == 401) rethrow;
        unread = 0;
      } catch (e) {
        debugPrint('[TrainerDashboard] Unread count ophalen fout: $e');
        unread = 0;
      }
      try {
        notifications = await api.getNotifications();
      } on ApiException catch (e) {
        if (e.statusCode == 401) rethrow;
        notifications = const [];
      } catch (e) {
        debugPrint('[TrainerDashboard] Notifications laden fout: $e');
        notifications = const [];
      }
      bool onboardingCompleted = false; // Default false: toon banner liever te vaak
      try {
        final onboarding = await api.getOnboardingStatus();
        final step = onboarding['current_step'] as String? ?? '';
        onboardingCompleted = step == 'completed';
      } on ApiException catch (e) {
        if (e.statusCode == 401) rethrow;
        // Bij API fout: toon banner zodat trainer onboarding niet mist
        onboardingCompleted = false;
        debugPrint('[TrainerDashboard] Onboarding status check mislukt: ${e.message}');
      } catch (e) {
        debugPrint('[TrainerDashboard] Onboarding status check fout: $e');
        onboardingCompleted = false;
      }
      if (kDebugMode) {
        try {
          final stats = await ActionRetryQueueService.getQueueStats();
          queuePending = stats['pending'] ?? 0;
          queueFailed = stats['failed'] ?? 0;
          queueHighRetry = stats['high_retry'] ?? 0;
        } catch (e) {
          debugPrint('[TrainerDashboard] Queue stats ophalen fout: $e');
          queuePending = 0;
          queueFailed = 0;
          queueHighRetry = 0;
        }
      }
      if (mounted) {
        _realtime()?.setUnreadCount(unread);
        setState(() {
          _summary = summary;
          _recentNotifications = _prioritizedNotifications(notifications);
          _queuePendingCount = queuePending;
          _queueFailedCount = queueFailed;
          _queueHighRetryCount = queueHighRetry;
          _onboardingCompleted = onboardingCompleted;
          _hasGymAccess = hasGymAccess;
          _loading = false;
        });
        if (!_hasAnimated) {
          _hasAnimated = true;
          _staggerController.forward();
        }
      }
    } on ApiException catch (e) {
      if (kDebugMode) debugPrint('[TrainerDashboard] *** ApiException *** ${e.statusCode} – ${e.message}');
      if (mounted) setState(() => _error = e.message);
      if (mounted) setState(() => _loading = false);
    } catch (e, st) {
      if (kDebugMode) debugPrint('[TrainerDashboard] *** Catch *** $e\n$st');
      if (mounted) setState(() => _error = 'Kon gegevens niet laden.');
      if (mounted) setState(() => _loading = false);
    }
  }

  String _userDisplayName() {
    final user = context.read<AuthService>().user;
    if (user == null) return 'trainer';
    final name = user['display_name'] ?? user['first_name'] ?? user['name'];
    if (name != null && name.toString().trim().isNotEmpty) {
      return name.toString().trim().split(RegExp(r'\s+')).first;
    }
    final email = user['email']?.toString().trim() ?? '';
    if (email.isNotEmpty) {
      final part = email.split('@').first;
      if (part.isNotEmpty) return part;
    }
    return 'trainer';
  }

  String _timeGreeting() {
    final hour = DateTime.now().hour;
    if (hour < 6) return 'Goedenacht';
    if (hour < 12) return 'Goedemorgen';
    if (hour < 18) return 'Goedemiddag';
    return 'Goedenavond';
  }

  Future<void> _logout() async {
    await context.read<AuthService>().logout();
    if (mounted) {
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const LoginRegisterScreen()),
        (route) => false,
      );
    }
  }

  void _pushScreen(Widget screen) {
    Navigator.of(context)
        .push(CupertinoPageRoute(builder: (_) => screen))
        .then((_) => _load());
  }

  void _openOnboarding() {
    Navigator.of(context)
        .push(CupertinoPageRoute(
            builder: (_) => const TrainerOnboardingScreen()))
        .then((_) => _load());
  }

  void _openMySessions() {
    Navigator.of(context).push(
      CupertinoPageRoute(builder: (_) => const TrainerSessionsScreen()),
    );
  }

  Future<void> _openNotifications() async {
    await Navigator.of(context).push(
      CupertinoPageRoute(builder: (_) => const TrainerNotificationsScreen()),
    );
    if (mounted) await _load();
  }

  /// Sessie in check-in venster? (15 min voor start tot 15 min na einde)
  bool _hasSessionInCheckInWindow() {
    final bookings = _summary?.upcomingBookings ?? [];
    final now = DateTime.now();
    for (final b in bookings) {
      final status = b.status.toLowerCase();
      if (status == 'cancelled' || status == 'completed') continue;
      final startWindow = b.scheduledAt.subtract(TimingConstants.checkInWindow);
      final endWindow = b.scheduledAt
          .add(Duration(minutes: b.durationMinutes))
          .add(TimingConstants.checkInWindow);
      if (!now.isBefore(startWindow) && !now.isAfter(endWindow)) {
        return true;
      }
    }
    return false;
  }

  Future<void> _openCheckInScanner() async {
    final changed = await Navigator.of(context).push<bool>(
      CupertinoPageRoute(
          builder: (_) => const TrainerCheckInScannerScreen()),
    );
    if (changed == true && mounted) await _load();
  }

  Future<void> _flushQueueNow() async {
    if (_queueFlushing) return;
    setState(() => _queueFlushing = true);
    try {
      final sent = await ActionRetryQueueService.flushPending(
        context.read<GymiesApi>(),
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Retry klaar: $sent actie(s) verstuurd')),
      );
      await _load();
    } finally {
      if (mounted) setState(() => _queueFlushing = false);
    }
  }

  String _queueHealthLabel() {
    if (_queueFailedCount >= 3 || _queueHighRetryCount > 0) {
      return 'Kritiek: $_queueFailedCount acties falen ($_queueHighRetryCount met hoge retries).';
    }
    if (_queuePendingCount > 0) {
      return '$_queuePendingCount actie(s) wachten op retry.';
    }
    return 'Alle achtergrondacties zijn gesynchroniseerd.';
  }

  Future<void> _openIncidentSupport() async {
    final draft = await ActionRetryQueueService.buildIncidentSupportDraft(
      contextLabel: 'TrainerDashboard',
    );
    if (!mounted) return;
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ClientSupportScreen(
          initialType: draft['type'],
          initialSubject: draft['subject'],
          initialMessage: draft['message'],
          initialBookingId: draft['booking_id'],
          initialInvoiceId: draft['invoice_id'],
          openComposerOnStart: true,
        ),
      ),
    );
    if (mounted) await _load();
  }

  bool _isUnread(Map<String, dynamic> item) {
    final unread = mapPick(item, ['unread', 'is_unread']);
    if (unread is bool) return unread;
    if (unread is num) return unread.toInt() == 1;
    return mapStr(item, ['read_at', 'readAt']).isEmpty;
  }

  DateTime _createdAt(Map<String, dynamic> item) {
    final raw = mapStr(item, ['created_at', 'createdAt', 'date']);
    return DateTime.tryParse(raw) ?? DateTime.fromMillisecondsSinceEpoch(0);
  }

  String _notificationCategory(Map<String, dynamic> item) {
    final text =
        '${mapStr(item, ['type', 'notification_type', 'category'])} '
                '${mapStr(item, ['title', 'subject'])} '
                '${mapStr(item, ['body', 'message', 'text'])}'
            .toLowerCase();
    if (text.contains('booking') ||
        text.contains('boeking') ||
        text.contains('session') ||
        text.contains('sessie')) {
      return 'Boeking';
    }
    if (text.contains('message') ||
        text.contains('bericht') ||
        text.contains('chat')) {
      return 'Bericht';
    }
    if (text.contains('invoice') ||
        text.contains('factuur') ||
        text.contains('payment') ||
        text.contains('payout') ||
        text.contains('revenue') ||
        text.contains('omzet')) {
      return 'Financieel';
    }
    return 'Update';
  }

  bool _requiresAction(Map<String, dynamic> item) {
    final status = mapStr(item, ['status']).toLowerCase();
    if (status == 'requires_action' || status == 'pending') return true;
    final text =
        '${mapStr(item, ['type', 'notification_type', 'category'])} '
                '${mapStr(item, ['title', 'subject'])} '
                '${mapStr(item, ['body', 'message', 'text'])}'
            .toLowerCase();
    return text.contains('actie') ||
        text.contains('urgent') ||
        text.contains('required') ||
        (text.contains('booking') && _isUnread(item));
  }

  IconData _categoryIcon(String category) {
    switch (category) {
      case 'Boeking':
        return Icons.event_rounded;
      case 'Bericht':
        return Icons.chat_bubble_outline_rounded;
      case 'Financieel':
        return Icons.euro_rounded;
      default:
        return Icons.notifications_outlined;
    }
  }

  Color _categoryColor(String category) {
    switch (category) {
      case 'Boeking':
        return Colors.blue.shade600;
      case 'Bericht':
        return Colors.teal.shade600;
      case 'Financieel':
        return Colors.green.shade600;
      default:
        return GymiesColors.darkBlue;
    }
  }

  List<Map<String, dynamic>> _prioritizedNotifications(
    List<Map<String, dynamic>> source,
  ) {
    final items = [...source];
    items.sort((a, b) {
      int score(Map<String, dynamic> n) {
        if (_requiresAction(n)) return 0;
        if (_isUnread(n)) return 1;
        return 2;
      }

      final byScore = score(a).compareTo(score(b));
      if (byScore != 0) return byScore;
      return _createdAt(b).compareTo(_createdAt(a));
    });
    return items.take(4).toList();
  }

  @override
  Widget build(BuildContext context) {
    final liveUnread = _realtime(listen: true)?.unreadCount ?? 0;
    final effectiveUnread = liveUnread;
    final s = _summary;
    return Scaffold(
      backgroundColor: const Color(0xFFF7F8FA),
      appBar: GymiesAppBar(
        title: 'GYMIES Trainer',
        actions: [
          if (_hasSessionInCheckInWindow())
            IconButton(
              tooltip: 'Scan check-in QR',
              onPressed: _openCheckInScanner,
              icon: const Icon(Icons.qr_code_scanner_rounded),
            ),
          IconButton(
            icon: Stack(
              clipBehavior: Clip.none,
              children: [
                const Icon(Icons.notifications_outlined),
                if (effectiveUnread > 0)
                  Positioned(
                    right: -6,
                    top: -4,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                      decoration: BoxDecoration(
                        color: Colors.red.shade700,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        effectiveUnread > 99 ? '99+' : '$effectiveUnread',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            tooltip: 'Meldingen',
            onPressed: _openNotifications,
          ),
        ],
        onAvatarTap: widget.onAvatarTap,
        avatarLabel: widget.avatarLabel,
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        color: GymiesColors.primary,
        child: CustomScrollView(
          slivers: [
            // ── Onboarding banner ──────────────────────────────────────
            if (!_onboardingCompleted && !_onboardingBannerDismissed)
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
                  child: GestureDetector(
                    onTap: _openOnboarding,
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.amber.shade50,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: Colors.amber.shade200),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.04),
                            blurRadius: 10,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                width: 40,
                                height: 40,
                                decoration: BoxDecoration(
                                  color: Colors.amber.shade100,
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Icon(Icons.rocket_launch_rounded, color: Colors.amber.shade800, size: 20),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Activeer je account',
                                      style: GoogleFonts.sora(fontSize: 15, fontWeight: FontWeight.w700, color: GymiesColors.darkBlue),
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      'Voltooi je onboarding om sessies aan te bieden.',
                                      style: GoogleFonts.sora(fontSize: 12, color: Colors.grey.shade700),
                                    ),
                                  ],
                                ),
                              ),
                              Icon(Icons.arrow_forward_ios_rounded, size: 14, color: Colors.grey.shade400),
                            ],
                          ),
                          const SizedBox(height: 12),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              TextButton(
                                onPressed: () => setState(() => _onboardingBannerDismissed = true),
                                style: TextButton.styleFrom(
                                  foregroundColor: Colors.grey.shade500,
                                  padding: const EdgeInsets.symmetric(horizontal: 12),
                                ),
                                child: Text('Later', style: GoogleFonts.sora(fontSize: 13)),
                              ),
                              const SizedBox(width: 8),
                              FilledButton(
                                onPressed: _openOnboarding,
                                style: FilledButton.styleFrom(
                                  backgroundColor: GymiesColors.primary,
                                  foregroundColor: GymiesColors.darkBlue,
                                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                                ),
                                child: Text('Nu activeren', style: GoogleFonts.sora(fontSize: 13, fontWeight: FontWeight.w600)),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),

            // ── Header met stats ───────────────────────────────────────
            SliverToBoxAdapter(
              child: _TrainerHeaderSection(
                greeting: _timeGreeting(),
                userDisplayName: _userDisplayName(),
                summary: s,
                loading: _loading,
                staggerController: _staggerController,
                onTapPending: () => _pushScreen(const TrainerSessionsScreen(initialTabIndex: 0)),
                onTapThisWeek: () => _pushScreen(const TrainerSessionsScreen(initialTabIndex: 1)),
                onTapCompleted: () => _pushScreen(const TrainerSessionsScreen(initialTabIndex: 2)),
                onTapRevenue: () => _pushScreen(const TrainerIncomeScreen()),
              ),
            ),

            // ── Debug queue status (kDebugMode only) ───────────────────
            if (kDebugMode)
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 12, 20, 4),
                  child: Container(
                    decoration: BoxDecoration(
                      color: (_queueFailedCount > 0 || _queueHighRetryCount > 0)
                          ? Colors.orange.shade50
                          : Colors.blue.shade50,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.04),
                          blurRadius: 8,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(
                              (_queueFailedCount > 0 || _queueHighRetryCount > 0)
                                  ? Icons.warning_amber_rounded
                                  : Icons.cloud_done_rounded,
                              color: (_queueFailedCount > 0 || _queueHighRetryCount > 0)
                                  ? Colors.orange.shade800
                                  : Colors.blue.shade700,
                              size: 20,
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text('Operationele status', style: GoogleFonts.sora(fontSize: 13, fontWeight: FontWeight.w600)),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text(_queueHealthLabel(), style: GoogleFonts.sora(fontSize: 12, color: Colors.grey.shade700)),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            OutlinedButton(
                              onPressed: _queueFlushing ? null : _flushQueueNow,
                              child: Text(_queueFlushing ? 'Bezig...' : 'Retry nu'),
                            ),
                            const SizedBox(width: 8),
                            if (_queueFailedCount >= 3 || _queueHighRetryCount > 0)
                              FilledButton(
                                onPressed: _openIncidentSupport,
                                style: FilledButton.styleFrom(
                                  backgroundColor: Colors.orange.shade700,
                                  foregroundColor: Colors.white,
                                ),
                                child: const Text('Meld incident'),
                              ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),

            // ── Error state ────────────────────────────────────────────
            if (_error != null)
              SliverToBoxAdapter(
                child: TrainerErrorView(
                  message: _error!,
                  onRetry: _load,
                  onLogout: (_error!.toLowerCase().contains('sessie') ||
                          _error!.toLowerCase().contains('verlopen'))
                      ? _logout
                      : null,
                ),
              )
            else ...[
              // ── Komende sessies header ───────────────────────────────
              SliverToBoxAdapter(
                child: _FadeSlide(
                  animation: _staggerAnimation(2),
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 24, 20, 10),
                    child: Row(
                      children: [
                        Container(
                          width: 32,
                          height: 32,
                          decoration: BoxDecoration(
                            color: GymiesColors.darkBlue.withValues(alpha: 0.08),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Icon(Icons.calendar_today_rounded, size: 16, color: GymiesColors.darkBlue),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            'Komende sessies',
                            style: GoogleFonts.sora(fontSize: 17, fontWeight: FontWeight.w700, color: GymiesColors.darkBlue),
                          ),
                        ),
                        GestureDetector(
                          onTap: _openMySessions,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                            decoration: BoxDecoration(
                              color: GymiesColors.darkBlue.withValues(alpha: 0.06),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.receipt_long_rounded, size: 14, color: GymiesColors.darkBlue),
                                const SizedBox(width: 4),
                                Text(
                                  'Facturen',
                                  style: GoogleFonts.sora(fontSize: 12, fontWeight: FontWeight.w600, color: GymiesColors.darkBlue),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              // ── Sessie lijst ─────────────────────────────────────────
              if (_loading && s == null)
                const SliverToBoxAdapter(child: TrainerLoadingView())
              else if (s == null || s.upcomingBookings.isEmpty)
                SliverToBoxAdapter(
                  child: _FadeSlide(
                    animation: _staggerAnimation(3),
                    child: TrainerEmptyState(
                      icon: Icons.event_available,
                      title: 'Geen komende sessies',
                      subtitle: 'Nieuwe boekingen verschijnen automatisch zodra een klant boekt.',
                      actionLabel: 'Open mijn sessies',
                      actionIcon: Icons.event_note_rounded,
                      onAction: _openMySessions,
                      padding: const EdgeInsets.all(24),
                    ),
                  ),
                )
              else
                SliverList(
                  delegate: SliverChildBuilderDelegate((_, i) {
                    final b = s.upcomingBookings[i];
                    return _FadeSlide(
                      animation: _staggerAnimation(3 + i, total: 3 + s.upcomingBookings.length + 3),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                        child: _BookingCard(booking: b, onTap: _openMySessions),
                      ),
                    );
                  }, childCount: s.upcomingBookings.length),
                ),

              // ── Prioriteit meldingen header ──────────────────────────
              SliverToBoxAdapter(
                child: _FadeSlide(
                  animation: _staggerAnimation(4),
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 24, 20, 10),
                    child: Row(
                      children: [
                        Container(
                          width: 32,
                          height: 32,
                          decoration: BoxDecoration(
                            color: Colors.orange.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Icon(Icons.priority_high_rounded, size: 16, color: Colors.orange.shade700),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            'Prioriteit meldingen',
                            style: GoogleFonts.sora(fontSize: 17, fontWeight: FontWeight.w700, color: GymiesColors.darkBlue),
                          ),
                        ),
                        GestureDetector(
                          onTap: _openNotifications,
                          child: Text(
                            'Alles bekijken',
                            style: GoogleFonts.sora(fontSize: 12, fontWeight: FontWeight.w600, color: GymiesColors.darkBlue.withValues(alpha: 0.6)),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              // ── Meldingen lijst ──────────────────────────────────────
              if (_recentNotifications.isEmpty)
                SliverToBoxAdapter(
                  child: _FadeSlide(
                    animation: _staggerAnimation(5),
                    child: const TrainerEmptyState(
                      icon: Icons.notifications_none_rounded,
                      title: 'Geen prioriteit meldingen',
                      subtitle: 'Nieuwe belangrijke updates verschijnen hier.',
                      padding: EdgeInsets.fromLTRB(24, 8, 24, 20),
                    ),
                  ),
                )
              else
                SliverList(
                  delegate: SliverChildBuilderDelegate((_, i) {
                    final n = _recentNotifications[i];
                    final title = mapStr(n, ['title', 'subject']).isNotEmpty
                        ? mapStr(n, ['title', 'subject'])
                        : 'Melding';
                    final body = mapStr(n, ['body', 'message', 'text']).isNotEmpty
                        ? mapStr(n, ['body', 'message', 'text'])
                        : '-';
                    final category = _notificationCategory(n);
                    final unread = _isUnread(n);
                    final action = _requiresAction(n);
                    final catIcon = _categoryIcon(category);
                    final catColor = _categoryColor(category);
                    return _FadeSlide(
                      animation: _staggerAnimation(5 + i, total: 5 + _recentNotifications.length),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                        child: GestureDetector(
                          onTap: () {
                            Haptics.selection();
                            _openNotifications();
                          },
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(
                                color: action
                                    ? Colors.red.shade200
                                    : unread
                                        ? GymiesColors.primary.withValues(alpha: 0.3)
                                        : Colors.grey.shade100,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withValues(alpha: 0.04),
                                  blurRadius: 10,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                            padding: const EdgeInsets.all(14),
                            child: Row(
                              children: [
                                Container(
                                  width: 40,
                                  height: 40,
                                  decoration: BoxDecoration(
                                    color: action
                                        ? Colors.red.shade50
                                        : catColor.withValues(alpha: 0.1),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Icon(
                                    action ? Icons.priority_high_rounded : catIcon,
                                    color: action ? Colors.red.shade700 : catColor,
                                    size: 20,
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          Expanded(
                                            child: Text(
                                              title,
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                              style: GoogleFonts.sora(
                                                fontSize: 14,
                                                fontWeight: unread ? FontWeight.w700 : FontWeight.w500,
                                                color: GymiesColors.darkBlue,
                                              ),
                                            ),
                                          ),
                                          if (unread)
                                            Container(
                                              width: 8,
                                              height: 8,
                                              margin: const EdgeInsets.only(left: 8),
                                              decoration: const BoxDecoration(
                                                color: GymiesColors.primary,
                                                shape: BoxShape.circle,
                                              ),
                                            ),
                                        ],
                                      ),
                                      const SizedBox(height: 3),
                                      Text(
                                        body,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: GoogleFonts.sora(fontSize: 12, color: Colors.grey.shade600),
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Icon(Icons.chevron_right_rounded, size: 18, color: Colors.grey.shade400),
                              ],
                            ),
                          ),
                        ),
                      ),
                    );
                  }, childCount: _recentNotifications.length),
                ),
            ],
            const SliverToBoxAdapter(child: SizedBox(height: 32)),
          ],
        ),
      ),
    );
  }
}

class _TrainerHeaderSection extends StatelessWidget {
  const _TrainerHeaderSection({
    required this.greeting,
    required this.userDisplayName,
    required this.summary,
    required this.loading,
    required this.staggerController,
    this.onTapPending,
    this.onTapThisWeek,
    this.onTapCompleted,
    this.onTapRevenue,
  });

  final String greeting;
  final String userDisplayName;
  final TrainerSummary? summary;
  final bool loading;
  final AnimationController staggerController;
  final VoidCallback? onTapPending;
  final VoidCallback? onTapThisWeek;
  final VoidCallback? onTapCompleted;
  final VoidCallback? onTapRevenue;

  String _formatRevenue(int cents) {
    final euros = cents / 100;
    if (euros >= 1000) {
      return '€${(euros / 1000).toStringAsFixed(1)}k';
    }
    return '€${euros.toStringAsFixed(euros.truncateToDouble() == euros ? 0 : 2)}';
  }

  Animation<double> _stagger(int index, {int total = 6}) {
    final start = (index / total).clamp(0.0, 1.0);
    final end = ((index + 1.5) / total).clamp(0.0, 1.0);
    return CurvedAnimation(parent: staggerController, curve: Interval(start, end, curve: Curves.easeOut));
  }

  @override
  Widget build(BuildContext context) {
    final dateStr = DateFormat('EEEE d MMMM', 'nl_NL').format(DateTime.now());

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            GymiesColors.darkBlue,
            GymiesColors.darkBlue.withValues(alpha: 0.95),
          ],
        ),
        borderRadius: const BorderRadius.vertical(bottom: Radius.circular(28)),
      ),
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Datum ──
          _FadeSlide(
            animation: _stagger(0),
            child: Text(
              dateStr,
              style: GoogleFonts.sora(fontSize: 12, fontWeight: FontWeight.w400, color: Colors.white54, letterSpacing: 0.3),
            ),
          ),
          const SizedBox(height: 2),
          // ── Begroeting ──
          _FadeSlide(
            animation: _stagger(0),
            child: Text(
              '$greeting, $userDisplayName',
              style: GoogleFonts.sora(fontSize: 22, fontWeight: FontWeight.w700, color: GymiesColors.primary, letterSpacing: 0.2),
            ),
          ),
          if (summary != null && summary!.upcomingBookings.isNotEmpty) ...[
            const SizedBox(height: 4),
            _FadeSlide(
              animation: _stagger(0),
              child: Text(
                summary!.upcomingBookings.length == 1
                    ? '1 sessie vandaag gepland'
                    : '${summary!.upcomingBookings.length} sessies gepland',
                style: GoogleFonts.sora(fontSize: 13, color: Colors.white60),
              ),
            ),
          ],
          const SizedBox(height: 18),
          // ── Stats ──
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 250),
            child: loading && summary == null
                ? Center(
                    key: const ValueKey('loading'),
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: SizedBox(
                        width: 28,
                        height: 28,
                        child: CircularProgressIndicator(
                          strokeWidth: 2.5,
                          color: GymiesColors.primary.withValues(alpha: 0.7),
                        ),
                      ),
                    ),
                  )
                : GridView.count(
                    key: const ValueKey('stats'),
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisCount: 2,
                    mainAxisSpacing: 10,
                    crossAxisSpacing: 10,
                    childAspectRatio: 1.9,
                    children: [
                      _FadeSlide(
                        animation: _stagger(1),
                        child: _StatCard(
                          icon: Icons.pending_actions_rounded,
                          iconColor: Colors.orange.shade400,
                          label: 'Te bevestigen',
                          value: '${summary?.pendingCount ?? 0}',
                          highlight: (summary?.pendingCount ?? 0) > 0,
                          onTap: onTapPending,
                        ),
                      ),
                      _FadeSlide(
                        animation: _stagger(1),
                        child: _StatCard(
                          icon: Icons.today_rounded,
                          iconColor: Colors.blue.shade300,
                          label: 'Deze week',
                          value: '${summary?.thisWeekCount ?? 0}',
                          onTap: onTapThisWeek,
                        ),
                      ),
                      _FadeSlide(
                        animation: _stagger(1),
                        child: _StatCard(
                          icon: Icons.check_circle_rounded,
                          iconColor: Colors.green.shade400,
                          label: 'Voltooid',
                          value: '${summary?.completedCount ?? 0}',
                          onTap: onTapCompleted,
                        ),
                      ),
                      _FadeSlide(
                        animation: _stagger(1),
                        child: _StatCard(
                          icon: Icons.trending_up_rounded,
                          iconColor: GymiesColors.primary,
                          label: 'Omzet',
                          value: _formatRevenue(summary?.revenueCents ?? 0),
                          onTap: onTapRevenue,
                        ),
                      ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({
    required this.icon,
    required this.label,
    required this.value,
    this.iconColor,
    this.highlight = false,
    this.onTap,
  });

  final IconData icon;
  final String label;
  final String value;
  final Color? iconColor;
  final bool highlight;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Haptics.selection();
        onTap?.call();
      },
      child: Container(
        decoration: BoxDecoration(
          color: highlight
              ? GymiesColors.primary.withValues(alpha: 0.14)
              : Colors.white.withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: highlight
                ? GymiesColors.primary.withValues(alpha: 0.5)
                : Colors.white.withValues(alpha: 0.12),
          ),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              children: [
                Container(
                  width: 26,
                  height: 26,
                  decoration: BoxDecoration(
                    color: (iconColor ?? GymiesColors.primary).withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(7),
                  ),
                  child: Icon(icon, color: iconColor ?? GymiesColors.primary, size: 14),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    label,
                    style: GoogleFonts.sora(fontSize: 11, fontWeight: FontWeight.w500, color: Colors.white60),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              value,
              style: GoogleFonts.sora(fontSize: 24, fontWeight: FontWeight.w700, color: Colors.white, height: 1.0),
            ),
          ],
        ),
      ),
    );
  }
}

class _BookingCard extends StatelessWidget {
  const _BookingCard({required this.booking, this.onTap});

  final Booking booking;
  final VoidCallback? onTap;

  static const _weekDays = ['ma', 'di', 'wo', 'do', 'vr', 'za', 'zo'];
  static const _months = [
    'jan', 'feb', 'mrt', 'apr', 'mei', 'jun',
    'jul', 'aug', 'sep', 'okt', 'nov', 'dec',
  ];

  String _formatSessionType(String? type) {
    if (type == null || type.isEmpty) return 'Sessie';
    switch (type.toLowerCase()) {
      case 'duo':
        return 'Duo';
      case 'groepsles':
      case 'group':
        return 'Groep';
      case '1-op-1':
      case '1op1':
      case 'personal':
        return 'PT';
      default:
        return '${type[0].toUpperCase()}${type.substring(1)}';
    }
  }

  bool _isToday(DateTime date) {
    final now = DateTime.now();
    return date.year == now.year && date.month == now.month && date.day == now.day;
  }

  @override
  Widget build(BuildContext context) {
    final date = booking.scheduledAt;
    final resolvedName = booking.clientName?.isNotEmpty == true
        ? booking.clientName!
        : booking.trainerName;
    final displayName = resolvedName.isNotEmpty ? resolvedName : 'Klant';
    final today = _isToday(date);
    final statusColor = _statusColor(booking.status);
    final typeLabel = _formatSessionType(booking.sessionType);

    return GestureDetector(
      onTap: () {
        Haptics.selection();
        onTap?.call();
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: today
                ? GymiesColors.primary.withValues(alpha: 0.5)
                : Colors.grey.shade100,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.04),
              blurRadius: 10,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            // ── Datum badge ──
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                color: today
                    ? GymiesColors.primary.withValues(alpha: 0.12)
                    : const Color(0xFFF7F8FA),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    '${date.day}',
                    style: GoogleFonts.sora(fontSize: 18, fontWeight: FontWeight.w700, color: GymiesColors.darkBlue, height: 1.1),
                  ),
                  Text(
                    _months[date.month - 1],
                    style: GoogleFonts.sora(
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      color: today ? GymiesColors.darkBlue : Colors.grey.shade500,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            // ── Info ──
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    displayName,
                    style: GoogleFonts.sora(fontSize: 14, fontWeight: FontWeight.w600, color: GymiesColors.darkBlue),
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${_weekDays[date.weekday - 1]} ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')} · $typeLabel · ${booking.durationMinutes} min',
                    style: GoogleFonts.sora(fontSize: 12, color: Colors.grey.shade500),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            // ── Status badge ──
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: statusColor.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                _statusLabel(booking.status),
                style: GoogleFonts.sora(fontSize: 11, fontWeight: FontWeight.w600, color: statusColor),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _statusColor(String status) {
    switch (status.toLowerCase()) {
      case 'confirmed':
        return Colors.green.shade700;
      case 'pending':
        return Colors.orange.shade700;
      case 'cancelled':
        return Colors.red.shade700;
      case 'checked_in':
        return Colors.blue.shade700;
      default:
        return GymiesColors.darkBlue;
    }
  }

  String _statusLabel(String status) {
    switch (status.toLowerCase()) {
      case 'confirmed':
        return 'Bevestigd';
      case 'pending':
        return 'Wachtend';
      case 'cancelled':
        return 'Geannuleerd';
      case 'checked_in':
        return 'Ingecheckt';
      default:
        return status;
    }
  }
}

/// Fade + slide-up animation wrapper for staggered entrance effects.
class _FadeSlide extends StatelessWidget {
  const _FadeSlide({required this.animation, required this.child});

  final Animation<double> animation;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: animation,
      child: SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(0, 0.08),
          end: Offset.zero,
        ).animate(animation),
        child: child,
      ),
    );
  }
}
