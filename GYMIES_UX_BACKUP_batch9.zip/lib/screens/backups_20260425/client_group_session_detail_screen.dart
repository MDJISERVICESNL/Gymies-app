import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../services/api_client.dart';
import '../utils/haptics.dart';
import '../services/gymies_api.dart';
import '../theme/gymies_theme.dart';
import '../utils/map_utils.dart';
import '../utils/safe_url_launcher.dart';
import 'widgets/gymies_dialog.dart';

/// Detail van een groepsles + inschrijven.
class ClientGroupSessionDetailScreen extends StatefulWidget {
  const ClientGroupSessionDetailScreen({
    super.key,
    required this.groupSessionId,
  });

  final String groupSessionId;

  @override
  State<ClientGroupSessionDetailScreen> createState() =>
      _ClientGroupSessionDetailScreenState();
}

class _ClientGroupSessionDetailScreenState
    extends State<ClientGroupSessionDetailScreen> {
  bool _loading = true;
  bool _busy = false;
  String? _error;
  Map<String, dynamic> _session = {};
  Map<String, dynamic>? _myRegistration;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final api = context.read<GymiesApi>();
      final session = await api.getPublicGroupSession(widget.groupSessionId);
      List<Map<String, dynamic>> myRegs = [];
      try {
        myRegs = await api.getMyGroupRegistrations();
      } catch (_) {
        myRegs = [];
      }
      if (!mounted) return;
      Map<String, dynamic>? myReg;
      for (final r in myRegs) {
        if (mapStr(r, ['group_session_id', 'groupSessionId']) ==
            widget.groupSessionId) {
          myReg = r;
          break;
        }
      }
      setState(() {
        _session = session;
        _myRegistration = myReg;
        _loading = false;
      });
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.message;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _error = 'Kon groepsles niet laden.';
        _loading = false;
      });
    }
  }

  Future<void> _register() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      final api = context.read<GymiesApi>();
      final res = await api.registerForGroupSession(widget.groupSessionId);
      if (!mounted) return;
      final participantId = mapStr(res, ['participant_id', 'participantId', 'id']);
      if (participantId.isNotEmpty) {
        final payRes = await api.startGroupParticipantPayment(participantId);
        final url = mapStr(payRes, [
          'payment_url',
          'checkout_url',
          'url',
        ]);
        if (url.isNotEmpty && mounted) {
          await SafeUrlLauncher.launchPaymentUrl(context, url);
        }
      }
      await _load();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Inschrijving voltooid'),
            backgroundColor: GymiesColors.darkBlue,
          ),
        );
      }
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.message), backgroundColor: Colors.red),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _cancelRegistration() async {
    if (_busy) return;
    final ok = await GymiesDialog.destructive(
      context,
      title: 'Inschrijving annuleren',
      message: 'Weet je zeker dat je je inschrijving wilt annuleren?',
      confirmLabel: 'Ja, annuleren',
    );
    if (ok != true || !mounted) return;
    setState(() => _busy = true);
    try {
      await context.read<GymiesApi>().cancelGroupSessionRegistration(
            widget.groupSessionId,
          );
      if (!mounted) return;
      await _load();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Inschrijving geannuleerd'),
            backgroundColor: GymiesColors.darkBlue,
          ),
        );
      }
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.message), backgroundColor: Colors.red),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      body: Column(
        children: [
          Container(
            decoration: const BoxDecoration(color: GymiesColors.darkBlue),
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                child: Row(
                  children: [
                    GestureDetector(
                      onTap: () {
                        Haptics.selection();
                        Navigator.of(context).pop();
                      },
                      child: const Padding(
                        padding: EdgeInsets.all(8),
                        child: Icon(
                          Icons.arrow_back_ios_rounded,
                          color: Colors.white,
                          size: 20,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Groepsles',
                        style: GoogleFonts.sora(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            child: _error != null
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(32),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 72,
                            height: 72,
                            decoration: BoxDecoration(
                              color: Colors.red.shade50,
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Icon(
                              Icons.error_outline_rounded,
                              size: 36,
                              color: Colors.red.shade700,
                            ),
                          ),
                          const SizedBox(height: 16),
                          Text(
                            _error!,
                            textAlign: TextAlign.center,
                            style: GoogleFonts.sora(
                              fontSize: 15,
                              color: Colors.grey.shade800,
                              height: 1.4,
                            ),
                          ),
                          const SizedBox(height: 20),
                          FilledButton.icon(
                            onPressed: () {
                              Haptics.light();
                              _load();
                            },
                            icon: const Icon(Icons.refresh_rounded, size: 18),
                            label: const Text('Opnieuw proberen'),
                            style: FilledButton.styleFrom(
                              backgroundColor: GymiesColors.primary,
                              foregroundColor: GymiesColors.darkBlue,
                              padding: const EdgeInsets.symmetric(
                                horizontal: 24,
                                vertical: 12,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  )
                : _loading
                    ? _buildLoadingSkeleton()
                    : RefreshIndicator(
                        onRefresh: _load,
                        color: GymiesColors.primary,
                        child: SingleChildScrollView(
                          physics: const AlwaysScrollableScrollPhysics(),
                          padding: const EdgeInsets.all(20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              // ── Titel ──
                              Text(
                                mapStr(_session, ['title', 'name']).isEmpty
                                    ? 'Groepsles'
                                    : mapStr(_session, ['title', 'name']),
                                style: GoogleFonts.sora(
                                  fontSize: 24,
                                  fontWeight: FontWeight.bold,
                                  color: GymiesColors.darkBlue,
                                ),
                              ),
                              const SizedBox(height: 6),
                              // ── Ingeschreven badge ──
                              if (_myRegistration != null)
                                Align(
                                  alignment: Alignment.centerLeft,
                                  child: Container(
                                    margin: const EdgeInsets.only(bottom: 16),
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 10,
                                      vertical: 4,
                                    ),
                                    decoration: BoxDecoration(
                                      color: Colors.green.withValues(alpha: 0.12),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Icon(Icons.check_circle_rounded,
                                            size: 14, color: Colors.green.shade700),
                                        const SizedBox(width: 4),
                                        Text(
                                          'Ingeschreven',
                                          style: GoogleFonts.sora(
                                            fontSize: 12,
                                            fontWeight: FontWeight.w600,
                                            color: Colors.green.shade700,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              if (_myRegistration == null)
                                const SizedBox(height: 10),

                              // ── Info kaart ──
                              Container(
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(16),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withValues(alpha: 0.05),
                                      blurRadius: 12,
                                      offset: const Offset(0, 3),
                                    ),
                                  ],
                                ),
                                child: Column(
                                  children: [
                                    _InfoTile(
                                      icon: Icons.calendar_today_rounded,
                                      iconColor: const Color(0xFF1565C0),
                                      iconBg: const Color(0xFFE3F2FD),
                                      label: 'Datum & tijd',
                                      value: _formatDateTime(
                                        DateTime.tryParse(mapStr(_session, [
                                              'starts_at',
                                              'startsAt',
                                              'start_at',
                                            ])) ??
                                            DateTime.now(),
                                      ),
                                      showDivider: true,
                                    ),
                                    _InfoTile(
                                      icon: Icons.person_outline_rounded,
                                      iconColor: const Color(0xFF6A1B9A),
                                      iconBg: const Color(0xFFF3E5F5),
                                      label: 'Trainer',
                                      value: mapStr(_session, [
                                        'trainer_name',
                                        'trainerName',
                                        'name',
                                      ]),
                                      showDivider: true,
                                    ),
                                    _InfoTile(
                                      icon: Icons.location_on_outlined,
                                      iconColor: const Color(0xFF2E7D32),
                                      iconBg: const Color(0xFFE8F5E9),
                                      label: 'Locatie',
                                      value: mapStr(
                                          _session, ['city', 'location', 'address']),
                                      showDivider: true,
                                    ),
                                    _InfoTile(
                                      icon: Icons.people_outline_rounded,
                                      iconColor: const Color(0xFFE65100),
                                      iconBg: const Color(0xFFFFF3E0),
                                      label: 'Plaatsen',
                                      value:
                                          '${mapStr(_session, ['enrolled_count', 'participants_count'])} / ${mapStr(_session, ['capacity', 'max_participants'])}',
                                      showDivider: false,
                                    ),
                                  ],
                                ),
                              ),

                              // ── Beschrijving ──
                              if (mapStr(_session, ['description', 'bio'])
                                  .isNotEmpty) ...[
                                const SizedBox(height: 20),
                                Container(
                                  width: double.infinity,
                                  padding: const EdgeInsets.all(16),
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(16),
                                    boxShadow: [
                                      BoxShadow(
                                        color:
                                            Colors.black.withValues(alpha: 0.05),
                                        blurRadius: 12,
                                        offset: const Offset(0, 3),
                                      ),
                                    ],
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        'Beschrijving',
                                        style: GoogleFonts.sora(
                                          fontSize: 13,
                                          fontWeight: FontWeight.w600,
                                          color: Colors.grey.shade500,
                                        ),
                                      ),
                                      const SizedBox(height: 8),
                                      Text(
                                        mapStr(
                                            _session, ['description', 'bio']),
                                        style: GoogleFonts.sora(
                                          color: Colors.grey.shade800,
                                          height: 1.5,
                                          fontSize: 14,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],

                              const SizedBox(height: 28),

                              // ── CTA ──
                              if (_myRegistration != null)
                                OutlinedButton.icon(
                                  onPressed: _busy
                                      ? null
                                      : () {
                                          Haptics.heavy();
                                          _cancelRegistration();
                                        },
                                  icon: _busy
                                      ? const SizedBox(
                                          width: 18,
                                          height: 18,
                                          child: CircularProgressIndicator(
                                            strokeWidth: 2,
                                          ),
                                        )
                                      : const Icon(Icons.cancel_outlined,
                                          size: 18),
                                  label: Text(
                                    'Inschrijving annuleren',
                                    style: GoogleFonts.sora(
                                        fontWeight: FontWeight.w600),
                                  ),
                                  style: OutlinedButton.styleFrom(
                                    foregroundColor: Colors.red.shade700,
                                    side: BorderSide(
                                        color: Colors.red.shade700),
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 16),
                                    shape: RoundedRectangleBorder(
                                      borderRadius:
                                          BorderRadius.circular(14),
                                    ),
                                  ),
                                )
                              else
                                Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(14),
                                    boxShadow: [
                                      BoxShadow(
                                        color: GymiesColors.primary
                                            .withValues(alpha: 0.35),
                                        blurRadius: 12,
                                        offset: const Offset(0, 4),
                                      ),
                                    ],
                                  ),
                                  child: FilledButton.icon(
                                    onPressed: _busy
                                        ? null
                                        : () {
                                            Haptics.light();
                                            _register();
                                          },
                                    icon: _busy
                                        ? const SizedBox(
                                            width: 18,
                                            height: 18,
                                            child:
                                                CircularProgressIndicator(
                                              strokeWidth: 2,
                                              color:
                                                  GymiesColors.darkBlue,
                                            ),
                                          )
                                        : const Icon(
                                            Icons
                                                .event_available_rounded,
                                            size: 20),
                                    label: Text(
                                      'Inschrijven',
                                      style: GoogleFonts.sora(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                    style: FilledButton.styleFrom(
                                      backgroundColor:
                                          GymiesColors.primary,
                                      foregroundColor:
                                          GymiesColors.darkBlue,
                                      padding:
                                          const EdgeInsets.symmetric(
                                              vertical: 16),
                                      shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(14),
                                      ),
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),
          ),
        ],
      ),
    );
  }

  String _formatDateTime(DateTime dt) {
    const days = ['Ma', 'Di', 'Wo', 'Do', 'Vr', 'Za', 'Zo'];
    const months = [
      'jan', 'feb', 'mrt', 'apr', 'mei', 'jun',
      'jul', 'aug', 'sep', 'okt', 'nov', 'dec',
    ];
    return '${days[dt.weekday - 1]} ${dt.day} ${months[dt.month - 1]} ${dt.year} · ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
  }

  Widget _buildLoadingSkeleton() {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _SkeletonBox(width: 200, height: 26),
          const SizedBox(height: 20),
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
            ),
            padding: const EdgeInsets.all(16),
            child: Column(
              children: List.generate(
                4,
                (i) => Padding(
                  padding: EdgeInsets.only(bottom: i < 3 ? 16 : 0),
                  child: Row(
                    children: [
                      _SkeletonBox(width: 40, height: 40, radius: 10),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _SkeletonBox(width: 70, height: 12),
                            const SizedBox(height: 6),
                            _SkeletonBox(width: 140, height: 16),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 28),
          _SkeletonBox(width: double.infinity, height: 52, radius: 14),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// SHIMMER SKELETON BOX
// ═══════════════════════════════════════════════════════════════════

class _SkeletonBox extends StatefulWidget {
  const _SkeletonBox({
    required this.width,
    required this.height,
    this.radius = 8,
  });
  final double width;
  final double height;
  final double radius;

  @override
  State<_SkeletonBox> createState() => _SkeletonBoxState();
}

class _SkeletonBoxState extends State<_SkeletonBox>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (context, _) {
        return Container(
          width: widget.width,
          height: widget.height,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(widget.radius),
            gradient: LinearGradient(
              begin: Alignment(-1.0 + 2.0 * _ctrl.value, 0),
              end: Alignment(-0.4 + 2.0 * _ctrl.value, 0),
              colors: [
                Colors.grey.shade200,
                Colors.grey.shade100,
                Colors.grey.shade200,
              ],
            ),
          ),
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// INFO TILE (iOS-stijl met icon container)
// ═══════════════════════════════════════════════════════════════════

class _InfoTile extends StatelessWidget {
  const _InfoTile({
    required this.icon,
    required this.iconColor,
    required this.iconBg,
    required this.label,
    required this.value,
    this.showDivider = false,
  });

  final IconData icon;
  final Color iconColor;
  final Color iconBg;
  final String label;
  final String value;
  final bool showDivider;

  @override
  Widget build(BuildContext context) {
    if (value.isEmpty) return const SizedBox.shrink();
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: iconBg,
                  borderRadius: BorderRadius.circular(10),
                ),
                alignment: Alignment.center,
                child: Icon(icon, size: 20, color: iconColor),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      label,
                      style: GoogleFonts.sora(
                        fontSize: 12,
                        color: Colors.grey.shade500,
                      ),
                    ),
                    const SizedBox(height: 1),
                    Text(
                      value,
                      style: GoogleFonts.sora(
                        fontWeight: FontWeight.w600,
                        fontSize: 15,
                        color: GymiesColors.darkBlue,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        if (showDivider)
          Divider(
            height: 0.5,
            thickness: 0.5,
            indent: 70,
            color: Colors.grey.shade200,
          ),
      ],
    );
  }
}
