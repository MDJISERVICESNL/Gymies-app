import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

import '../services/api_client.dart';
import '../services/gymies_api.dart';
import '../theme/gymies_theme.dart';
import '../utils/map_utils.dart';
import 'widgets/gymies_app_bar.dart';
import 'widgets/gymies_dialog.dart';
import 'widgets/trainer_state_views.dart';
import '../utils/haptics.dart';

class TrainerProHubScreen extends StatefulWidget {
  const TrainerProHubScreen({super.key});

  @override
  State<TrainerProHubScreen> createState() => _TrainerProHubScreenState();
}

class _TrainerProHubScreenState extends State<TrainerProHubScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _loading = true;
  bool _busy = false;
  String? _error;
  List<Map<String, dynamic>> _health = [];
  List<Map<String, dynamic>> _upsell = [];
  List<Map<String, dynamic>> _rebook = [];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _load();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final api = context.read<GymiesApi>();
      final results = await Future.wait([
        api.getTrainerClientHealthScores(),
        api.getTrainerUpsellSuggestions(),
        api.getTrainerRebookSuggestions(),
      ]);
      if (!mounted) return;
      setState(() {
        _health = (results[0] is List)
            ? List<Map<String, dynamic>>.from(results[0] as List)
            : <Map<String, dynamic>>[];
        _upsell = (results[1] is List)
            ? List<Map<String, dynamic>>.from(results[1] as List)
            : <Map<String, dynamic>>[];
        _rebook = (results[2] is List)
            ? List<Map<String, dynamic>>.from(results[2] as List)
            : <Map<String, dynamic>>[];
        _loading = false;
      });
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.message;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _error = 'Kon Pro Hub niet laden.';
        _loading = false;
      });
    }
  }

  Color _healthColor(int score) {
    if (score >= 75) return Colors.green.shade700;
    if (score >= 50) return Colors.orange.shade800;
    return Colors.red.shade700;
  }

  Future<void> _sendUpsell(Map<String, dynamic> item) async {
    Haptics.light();
    if (_busy) return;
    final suggestionId = mapStr(item, [
      'id',
      'suggestion_id',
      'suggestionId',
    ]).trim();
    if (suggestionId.isEmpty) return;
    setState(() => _busy = true);
    try {
      await context.read<GymiesApi>().sendTrainerUpsellSuggestion(
        suggestionId: suggestionId,
        clientUserId: mapStr(item, ['client_user_id', 'clientUserId']),
        packageId: mapStr(item, ['package_id', 'packageId']),
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Upsell voorstel verstuurd'),
          backgroundColor: GymiesColors.darkBlue,
        ),
      );
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.message), backgroundColor: Colors.red),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _sendRebook(Map<String, dynamic> item) async {
    Haptics.light();
    if (_busy) return;
    final clientUserId = mapStr(item, [
      'id',
      'client_user_id',
      'clientUserId',
    ]).trim();
    if (clientUserId.isEmpty) return;
    setState(() => _busy = true);
    try {
      await context.read<GymiesApi>().sendTrainerBulkMessage(
        clientUserIds: [clientUserId],
        body:
            'We missen je! Plan je volgende sessie via Mijn afspraken in de app.',
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('We missen je-bericht verstuurd'),
          backgroundColor: GymiesColors.darkBlue,
        ),
      );
      _load();
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.message), backgroundColor: Colors.red),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _openPrioritySupportComposer() async {
    Haptics.selection();
    final issueCtrl = TextEditingController();
    final bookingCtrl = TextEditingController();
    final submit = await GymiesDialog.custom<bool>(
      context,
      title: 'Priority support lane',
      icon: Icons.priority_high_rounded,
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: issueCtrl,
            maxLines: 3,
            decoration: const InputDecoration(
              labelText: 'Issue',
              hintText: 'Beschrijf kort het urgente probleem',
            ),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: bookingCtrl,
            decoration: const InputDecoration(
              labelText: 'Booking reference (optioneel)',
            ),
          ),
        ],
      ),
      actions: [
        GymiesDialogAction(
          label: 'Annuleren',
          returnValue: false,
        ),
        GymiesDialogAction(
          label: 'Verstuur',
          isPrimary: true,
          returnValue: true,
        ),
      ],
    );
    if (submit != true || issueCtrl.text.trim().isEmpty) return;
    if (!mounted) return;
    try {
      await context.read<GymiesApi>().createSupportTicket(
        type: 'incident',
        subject: 'Priority support lane',
        message:
            'Priority issue: ${issueCtrl.text.trim()}\nBookingRef: ${bookingCtrl.text.trim().isEmpty ? '-' : bookingCtrl.text.trim()}\nSource: TrainerProHub',
        bookingId: bookingCtrl.text.trim(),
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Priority support ticket verstuurd'),
          backgroundColor: GymiesColors.darkBlue,
        ),
      );
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.message), backgroundColor: Colors.red),
      );
    }
  }

  Widget _healthTab() {
    if (_health.isEmpty) {
      return const Center(
        child: Text('Nog geen health score data beschikbaar.'),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _health.length,
      itemBuilder: (_, i) {
        final item = _health[i];
        final name = mapStr(item, ['client_name', 'name', 'full_name']).isEmpty
            ? 'Klant'
            : mapStr(item, ['client_name', 'name', 'full_name']);
        final score = mapInt(item, ['health_score', 'score']);
        final retentionRisk = mapStr(item, [
          'retention_risk',
          'risk_label',
          'risk',
        ]);
        final noShowRisk = mapStr(item, ['no_show_risk', 'noshow_risk']);
        return Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 10, offset: const Offset(0, 2))],
            ),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: _healthColor(score).withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Center(
                    child: Text(
                      '$score',
                      style: TextStyle(
                        color: _healthColor(score),
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(name, style: GoogleFonts.sora(fontWeight: FontWeight.w600, color: GymiesColors.darkBlue)),
                      const SizedBox(height: 4),
                      Text(
                        'Retention: ${retentionRisk.isEmpty ? '-' : retentionRisk} · No-show: ${noShowRisk.isEmpty ? '-' : noShowRisk}',
                        style: GoogleFonts.sora(fontSize: 13, color: Colors.grey.shade600),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _upsellTab() {
    if (_upsell.isEmpty) {
      return const Center(
        child: Text('Nog geen upsell suggesties beschikbaar.'),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _upsell.length,
      itemBuilder: (_, i) {
        final item = _upsell[i];
        final name = mapStr(item, ['client_name', 'name']).isEmpty
            ? 'Klant'
            : mapStr(item, ['client_name', 'name']);
        final reason = mapStr(item, ['reason', 'explanation']);
        final packageName = mapStr(item, [
          'package_name',
          'offer',
          'target_package',
        ]);
        return Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 10, offset: const Offset(0, 2))]),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name, style: const TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                Text(
                  packageName.isEmpty
                      ? 'Aanbeveling: pakket-upgrade'
                      : 'Aanbeveling: $packageName',
                ),
                if (reason.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Text(reason),
                ],
                const SizedBox(height: 8),
                Align(
                  alignment: Alignment.centerRight,
                  child: FilledButton.icon(
                    onPressed: _busy ? null : () => _sendUpsell(item),
                    style: FilledButton.styleFrom(
                      backgroundColor: GymiesColors.primary,
                      foregroundColor: GymiesColors.darkBlue,
                    ),
                    icon: const Icon(Icons.trending_up_rounded),
                    label: const Text('Stuur voorstel'),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _rebookTab() {
    if (_rebook.isEmpty) {
      return const Center(
        child: Text(
          'Geen Smart Rebook alerts.\nKlanten verschijnen hier als ze langer dan 7 dagen geen sessie hadden.',
          textAlign: TextAlign.center,
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _rebook.length,
      itemBuilder: (_, i) {
        final item = _rebook[i];
        final name = mapStr(item, ['client_name', 'name']).isEmpty
            ? 'Klant'
            : mapStr(item, ['client_name', 'name']);
        final daysSince = mapInt(item, ['days_since_last', 'daysSinceLast']);
        final lastAt = mapStr(item, ['last_session_at', 'lastSessionAt']);
        return Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 10, offset: const Offset(0, 2))]),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name, style: const TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                Text(
                  daysSince > 0
                      ? '${daysSince == 1 ? '1 dag' : '$daysSince dagen'} geleden laatste sessie'
                      : (lastAt.isEmpty
                          ? 'Laatste sessie meer dan 7 dagen geleden'
                          : lastAt),
                ),
                const SizedBox(height: 8),
                Align(
                  alignment: Alignment.centerRight,
                  child: FilledButton.icon(
                    onPressed: _busy ? null : () => _sendRebook(item),
                    style: FilledButton.styleFrom(
                      backgroundColor: GymiesColors.primary,
                      foregroundColor: GymiesColors.darkBlue,
                    ),
                    icon: const Icon(Icons.favorite_rounded),
                    label: const Text('We missen je'),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _supportTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 10, offset: const Offset(0, 2))]),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Priority support lane',
                  style: GoogleFonts.sora(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: GymiesColors.darkBlue,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Voor urgente operationele issues met contextpakket (issue + booking refs).',
                ),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: _openPrioritySupportComposer,
                    style: FilledButton.styleFrom(
                      backgroundColor: GymiesColors.primary,
                      foregroundColor: GymiesColors.darkBlue,
                    ),
                    icon: const Icon(Icons.priority_high_rounded),
                    label: const Text('Open priority lane'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F8FA),
      appBar: GymiesAppBar(
        title: 'Pro Hub',
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(46),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            child: TabBar(
              controller: _tabController,
              indicatorSize: TabBarIndicatorSize.tab,
              dividerColor: Colors.transparent,
              indicator: BoxDecoration(
                color: GymiesColors.primary.withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(20),
              ),
              labelColor: GymiesColors.primary,
              unselectedLabelColor: Colors.white70,
              labelStyle: GoogleFonts.sora(fontSize: 13, fontWeight: FontWeight.w600),
              unselectedLabelStyle: GoogleFonts.sora(fontSize: 13),
              tabs: const [
                Tab(text: 'Health'),
                Tab(text: 'Upsell'),
                Tab(text: 'Herboek'),
                Tab(text: 'Priority'),
              ],
            ),
          ),
        ),
      ),
      body: GymiesListBody(
        loading: _loading,
        error: _error,
        onRefresh: _load,
        child: TabBarView(
              controller: _tabController,
              children: [
                _healthTab(),
                _upsellTab(),
                _rebookTab(),
                _supportTab(),
              ],
            ),
      ),
    );
  }
}
