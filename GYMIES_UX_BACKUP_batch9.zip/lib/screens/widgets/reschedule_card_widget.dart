import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../theme/gymies_theme.dart';

/// Interactieve Reschedule_Card in chat – Akkoord / Afwijzen / Ander voorstel.
/// Toont verzetverzoek en knoppen om te reageren.
class RescheduleCardWidget extends StatelessWidget {
  const RescheduleCardWidget({
    super.key,
    required this.bookingId,
    required this.originalDate,
    required this.requestedDate,
    this.trainerName,
    this.status,
    this.onAccept,
    this.onReject,
    this.onCounterPropose,
    this.busy = false,
  });

  final String bookingId;
  final DateTime originalDate;
  final DateTime requestedDate;
  final String? trainerName;
  final String? status;
  final VoidCallback? onAccept;
  final VoidCallback? onReject;
  final VoidCallback? onCounterPropose;
  final bool busy;

  /// Haalt booking_id uit een reschedule-bericht.
  static String getBookingIdFromMessage(Map<String, dynamic> message) {
    final data = message['data'] is Map
        ? Map<String, dynamic>.from(message['data'])
        : message;
    final rescheduleReq = data['reschedule_request'];
    final reqMap = rescheduleReq is Map
        ? Map<String, dynamic>.from(rescheduleReq)
        : data;
    final id = _str(reqMap, ['booking_id', 'bookingId']);
    return id.isEmpty ? _str(data, ['booking_id', 'bookingId']) : id;
  }

  /// Controleert of een bericht een reschedule-card is.
  static bool isRescheduleCard(Map<String, dynamic> message) {
    final type = (message['type'] ?? message['card_type'] ?? '')
        .toString()
        .toLowerCase();
    if (type.contains('reschedule') || type.contains('verplaats')) {
      return true;
    }
    final data = message['data'];
    if (data is Map && data.containsKey('reschedule_request')) {
      return true;
    }
    return message.containsKey('reschedule_request') ||
        message.containsKey('booking_id') &&
            (message.containsKey('requested_at') ||
                message.containsKey('requestedAt'));
  }

  /// Maakt een RescheduleCardWidget uit een bericht.
  static RescheduleCardWidget? fromMessage(
    Map<String, dynamic> message, {
    VoidCallback? onAccept,
    VoidCallback? onReject,
    VoidCallback? onCounterPropose,
    bool busy = false,
  }) {
    if (!isRescheduleCard(message)) return null;
    final data = message['data'] is Map
        ? Map<String, dynamic>.from(message['data'])
        : message;
    final rescheduleReq = data['reschedule_request'];
    final reqMap = rescheduleReq is Map
        ? Map<String, dynamic>.from(rescheduleReq)
        : data;
    final bookingId = _str(reqMap, ['booking_id', 'bookingId'])
        .trim()
        .isEmpty
        ? _str(data, ['booking_id', 'bookingId'])
        : _str(reqMap, ['booking_id', 'bookingId']);
    if (bookingId.isEmpty) return null;
    final originalRaw = _str(reqMap, ['scheduled_at', 'scheduledAt', 'original_at'])
        .isEmpty
        ? _str(data, ['scheduled_at', 'scheduledAt', 'original_at'])
        : _str(reqMap, ['scheduled_at', 'scheduledAt', 'original_at']);
    final requestedRaw = _str(reqMap, ['requested_at', 'requestedAt'])
        .isEmpty
        ? _str(data, ['requested_at', 'requestedAt'])
        : _str(reqMap, ['requested_at', 'requestedAt']);
    final original = DateTime.tryParse(originalRaw) ?? DateTime.now();
    final requested = DateTime.tryParse(requestedRaw) ?? DateTime.now();
    return RescheduleCardWidget(
      bookingId: bookingId,
      originalDate: original,
      requestedDate: requested,
      trainerName: _str(reqMap, ['trainer_name', 'trainerName']).isEmpty
          ? _str(data, ['trainer_name', 'trainerName'])
          : _str(reqMap, ['trainer_name', 'trainerName']),
      status: _str(reqMap, ['status']).isEmpty
          ? _str(data, ['status'])
          : _str(reqMap, ['status']),
      onAccept: onAccept,
      onReject: onReject,
      onCounterPropose: onCounterPropose,
      busy: busy,
    );
  }

  static String _str(Map<String, dynamic> m, List<String> keys) {
    for (final k in keys) {
      final v = m[k];
      if (v != null && v.toString().trim().isNotEmpty) return v.toString();
    }
    return '';
  }

  String _formatDate(DateTime d) {
    return '${d.day}/${d.month}/${d.year} ${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final canRespond = status != 'accepted' &&
        status != 'rejected' &&
        status != 'cancelled' &&
        (onAccept != null || onReject != null || onCounterPropose != null);
    return Container(
      constraints: const BoxConstraints(maxWidth: 300),
      margin: const EdgeInsets.symmetric(vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: GymiesColors.primary.withValues(alpha: 0.5)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.08),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Icon(
                  Icons.event_repeat_rounded,
                  color: GymiesColors.primary,
                  size: 24,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Verplaatsingsverzoek',
                    style: GoogleFonts.sora(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: GymiesColors.darkBlue,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              'Oorspronkelijk: ${_formatDate(originalDate)}',
              style: TextStyle(
                fontSize: 13,
                color: Colors.grey.shade700,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'Gevraagd: ${_formatDate(requestedDate)}',
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: GymiesColors.darkBlue,
              ),
            ),
            if (trainerName != null && trainerName!.isNotEmpty) ...[
              const SizedBox(height: 4),
              Text(
                trainerName!,
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.grey.shade600,
                ),
              ),
            ],
            if (canRespond && !busy) ...[
              const SizedBox(height: 14),
              Row(
                children: [
                  if (onAccept != null)
                    Expanded(
                      child: FilledButton(
                        onPressed: onAccept,
                        style: FilledButton.styleFrom(
                          backgroundColor: Colors.green.shade600,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 10),
                        ),
                        child: const Text('Akkoord'),
                      ),
                    ),
                  if (onAccept != null && (onReject != null || onCounterPropose != null))
                    const SizedBox(width: 8),
                  if (onReject != null)
                    Expanded(
                      child: OutlinedButton(
                        onPressed: onReject,
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.red.shade700,
                          side: BorderSide(color: Colors.red.shade700),
                          padding: const EdgeInsets.symmetric(vertical: 10),
                        ),
                        child: const Text('Afwijzen'),
                      ),
                    ),
                ],
              ),
              if (onCounterPropose != null) ...[
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: onCounterPropose,
                    icon: const Icon(Icons.schedule_rounded, size: 18),
                    label: const Text('Ander voorstel'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: GymiesColors.darkBlue,
                      side: const BorderSide(color: GymiesColors.primary),
                      padding: const EdgeInsets.symmetric(vertical: 10),
                    ),
                  ),
                ),
              ],
            ],
            if (busy)
              const Padding(
                padding: EdgeInsets.only(top: 12),
                child: Center(
                  child: SizedBox(
                    width: 24,
                    height: 24,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
